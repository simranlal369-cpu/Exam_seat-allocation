import os
import unittest
import tempfile
import sqlite3
from app import create_app
from database import init_db, seed_sample_data, get_db
from werkzeug.security import check_password_hash

class ExamSeatSystemTestCase(unittest.TestCase):
    def setUp(self):
        # Create a temporary database for isolated testing
        self.db_fd, self.db_path = tempfile.mkstemp()
        self.app = create_app({
            'TESTING': True,
            'DATABASE': self.db_path,
            'SECRET_KEY': 'test-secret-key'
        })
        self.client = self.app.test_client()

        with self.app.app_context():
            init_db(self.app)
            seed_sample_data(self.app)

    def tearDown(self):
        os.close(self.db_fd)
        os.unlink(self.db_path)

    def get_csrf_token(self, response_data):
        """Helper to extract CSRF token from HTML form."""
        html = response_data.decode('utf-8')
        prefix = 'name="csrf_token" value="'
        start = html.find(prefix)
        if start != -1:
            start += len(prefix)
            end = html.find('"', start)
            return html[start:end]
        return None

    def login_admin(self):
        """Log in with default admin credentials."""
        res = self.client.get('/login')
        token = self.get_csrf_token(res.data)
        return self.client.post('/login', data={
            'username': 'admin',
            'password': 'admin123',
            'csrf_token': token
        }, follow_redirects=True)

    def test_database_initialization_and_seed(self):
        """Test database tables and seed records."""
        with self.app.app_context():
            db = get_db()
            cur = db.cursor()

            # Check admin user
            cur.execute("SELECT username, email, password_hash FROM users WHERE username = 'admin'")
            admin = cur.fetchone()
            self.assertIsNotNone(admin)
            self.assertTrue(check_password_hash(admin['password_hash'], 'admin123'))

            # Check sample students
            cur.execute("SELECT COUNT(*) AS c FROM students")
            self.assertGreaterEqual(cur.fetchone()['c'], 30)

            # Check sample rooms
            cur.execute("SELECT COUNT(*) AS c FROM rooms")
            self.assertGreaterEqual(cur.fetchone()['c'], 5)

            # Check sample examinations
            cur.execute("SELECT COUNT(*) AS c FROM examinations")
            self.assertGreaterEqual(cur.fetchone()['c'], 4)

            # Check pre-seeded allocations
            cur.execute("SELECT COUNT(*) AS c FROM allocations")
            self.assertGreaterEqual(cur.fetchone()['c'], 20)

    def test_authentication_workflow(self):
        """Test login validation, wrong credentials, session protection, and logout."""
        # Unauthenticated access to dashboard should redirect
        res = self.client.get('/dashboard')
        self.assertEqual(res.status_code, 302)
        self.assertIn('/login', res.headers['Location'])

        # Invalid password
        res = self.client.get('/login')
        token = self.get_csrf_token(res.data)
        res_fail = self.client.post('/login', data={
            'username': 'admin',
            'password': 'wrongpassword',
            'csrf_token': token
        }, follow_redirects=True)
        self.assertIn(b'Invalid credentials', res_fail.data)

        # Valid login
        res_login = self.client.post('/login', data={
            'username': 'admin',
            'password': 'admin123',
            'csrf_token': token
        }, follow_redirects=True)
        self.assertEqual(res_login.status_code, 200)
        self.assertIn(b'Examination Control Dashboard', res_login.data)

        # Logout
        res_logout = self.client.get('/logout', follow_redirects=True)
        self.assertIn(b'logged out successfully', res_logout.data)

    def test_csrf_protection(self):
        """Test that state-changing POST requests reject invalid or missing CSRF tokens."""
        self.login_admin()

        # POST without CSRF token should be rejected (redirected with error)
        res = self.client.post('/students/add', data={
            'roll_no': '2026TEST01',
            'name': 'CSRF Test Student',
            'department': 'CS',
            'course': 'B.Tech',
            'semester': '4'
        }, follow_redirects=True)
        self.assertIn(b'Security session expired or invalid CSRF token', res.data)

    def test_students_crud_and_uniqueness(self):
        """Test adding student, validating duplicate roll numbers, editing, and deleting."""
        self.login_admin()

        # Get token from students page
        res = self.client.get('/students')
        token = self.get_csrf_token(res.data)

        # 1. Add valid student
        res_add = self.client.post('/students/add', data={
            'roll_no': '2026TEST99',
            'name': 'Test Student 99',
            'email': 'test99@apex.edu',
            'department': 'Computer Science',
            'course': 'B.Tech CSE',
            'semester': '4',
            'csrf_token': token
        }, follow_redirects=True)
        self.assertIn(b'added successfully', res_add.data)

        # 2. Add duplicate roll number
        res_dup = self.client.post('/students/add', data={
            'roll_no': '2026TEST99',
            'name': 'Another Student',
            'email': 'another@apex.edu',
            'department': 'Computer Science',
            'course': 'B.Tech CSE',
            'semester': '4',
            'csrf_token': token
        }, follow_redirects=True)
        self.assertIn(b'already exists', res_dup.data)

        # 3. Filter students by department
        res_filter = self.client.get('/students?department=Computer+Science')
        self.assertEqual(res_filter.status_code, 200)
        self.assertIn(b'2026TEST99', res_filter.data)

        # 4. Search student
        res_search = self.client.get('/students?q=Test+Student+99')
        self.assertEqual(res_search.status_code, 200)
        self.assertIn(b'2026TEST99', res_search.data)

    def test_room_safety_and_deletion_guard(self):
        """Test that rooms with active allocations cannot be deleted."""
        self.login_admin()

        with self.app.app_context():
            db = get_db()
            cur = db.cursor()
            # Find a room with active allocations
            cur.execute("""
                SELECT r.id, r.room_number FROM rooms r
                JOIN allocations a ON r.id = a.room_id
                LIMIT 1
            """)
            allocated_room = cur.fetchone()
            self.assertIsNotNone(allocated_room)
            room_id = allocated_room['id']

        res = self.client.get('/rooms')
        token = self.get_csrf_token(res.data)

        # Attempt to delete room with active allocations
        res_del = self.client.post(f'/rooms/delete/{room_id}', data={
            'csrf_token': token
        }, follow_redirects=True)
        self.assertIn(b'Security Protection: Cannot delete Room', res_del.data)

    def test_seat_allocation_and_seating_plan(self):
        """Test full seat allocation engine execution, label formatting, and seating matrix."""
        self.login_admin()

        with self.app.app_context():
            db = get_db()
            cur = db.cursor()
            # Pick exam IT502
            cur.execute("SELECT id FROM examinations WHERE exam_code = 'IT502-2026'")
            it_exam = cur.fetchone()
            exam_id = it_exam['id']

            # Pick rooms
            cur.execute("SELECT id FROM rooms LIMIT 2")
            rooms = cur.fetchall()
            room_ids = [r['id'] for r in rooms]

        res = self.client.get(f'/allocate?exam_id={exam_id}')
        token = self.get_csrf_token(res.data)

        # Execute allocation
        post_data = {
            'exam_id': exam_id,
            'room_ids': room_ids,
            'confirm_overwrite': 'yes',
            'csrf_token': token
        }
        res_alloc = self.client.post('/allocate', data=post_data, follow_redirects=True)
        self.assertEqual(res_alloc.status_code, 200)
        self.assertIn(b'Successfully generated seating plan', res_alloc.data)

        # Verify seating plan route
        res_plan = self.client.get(f'/seating-plan?exam_id={exam_id}&room_id={room_ids[0]}')
        self.assertEqual(res_plan.status_code, 200)
        self.assertIn(b'Front of Hall', res_plan.data)
        self.assertIn(b'desk-occupied', res_plan.data)

    def test_find_my_seat_public_portal(self):
        """Test that students can search by roll number or name publicly."""
        # Find My Seat is accessible without login
        res = self.client.get('/find-my-seat')
        self.assertEqual(res.status_code, 200)

        # Search for a seeded student (e.g. 2026CS101)
        res_search = self.client.get('/find-my-seat?q=2026CS101')
        self.assertEqual(res_search.status_code, 200)
        self.assertIn(b'Aarav Patel', res_search.data)
        self.assertIn(b'Assigned Seat', res_search.data)

        # Search for a non-existent student
        res_none = self.client.get('/find-my-seat?q=NONEXISTENT999')
        self.assertEqual(res_none.status_code, 200)
        self.assertIn(b'No Seating Record Found', res_none.data)

    def test_reports_and_csv_export(self):
        """Test complete reports view, room-wise attendance sheet, and CSV export."""
        self.login_admin()

        # Master report
        res_rep = self.client.get('/reports?view=complete')
        self.assertEqual(res_rep.status_code, 200)
        self.assertIn(b'Seat Label', res_rep.data)

        # Room-wise attendance sheet
        res_room = self.client.get('/reports?view=room')
        self.assertEqual(res_room.status_code, 200)
        self.assertIn(b'Student Signature', res_room.data)

        # CSV Export
        res_csv = self.client.get('/reports/export/csv')
        self.assertEqual(res_csv.status_code, 200)
        self.assertEqual(res_csv.content_type, 'text/csv; charset=utf-8')
        self.assertIn(b'Roll Number,Student Name,Department', res_csv.data)

if __name__ == '__main__':
    unittest.main()

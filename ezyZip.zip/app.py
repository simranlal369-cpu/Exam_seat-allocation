import os
import csv
import io
from datetime import datetime
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, session, g, make_response, jsonify, abort
)
from config import Config
from database import get_db, close_db, init_db, seed_sample_data
from auth import (
    login_required, generate_csrf_token, verify_csrf_token,
    hash_password, verify_password
)
import allocation_engine

def create_app(test_config=None):
    """Application factory for ExamSeat."""
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    # Register teardown
    app.teardown_appcontext(close_db)

    # Ensure database exists
    with app.app_context():
        db_path = app.config.get('DATABASE', Config.DATABASE)
        if not os.path.exists(db_path):
            init_db(app)
            seed_sample_data(app)

    # Context processors: make CSRF token, current_user, and system settings available in templates
    @app.context_processor
    def inject_globals():
        db = get_db()
        cur = db.cursor()
        
        # Load system settings
        settings_dict = {}
        try:
            cur.execute("SELECT key, value FROM system_settings")
            for row in cur.fetchall():
                settings_dict[row['key']] = row['value']
        except Exception:
            pass

        # Load current user info if logged in
        current_user = None
        if 'user_id' in session:
            try:
                cur.execute("SELECT id, username, email, full_name, role FROM users WHERE id = ?", (session['user_id'],))
                user_row = cur.fetchone()
                if user_row:
                    current_user = dict(user_row)
            except Exception:
                pass

        return {
            'csrf_token': generate_csrf_token(),
            'current_user': current_user,
            'sys_settings': settings_dict,
            'now': datetime.now()
        }

    # Custom CSRF validation before request for state-changing methods
    @app.before_request
    def check_csrf():
        if request.method in ['POST', 'PUT', 'DELETE', 'PATCH']:
            # Find token in form, headers, or json
            token = request.form.get('csrf_token') or request.headers.get('X-CSRFToken')
            if not token and request.is_json:
                token = request.get_json(silent=True, force=False)
                if isinstance(token, dict):
                    token = token.get('csrf_token')

            if not verify_csrf_token(token):
                if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return jsonify({'error': 'Invalid or expired CSRF token. Please refresh the page.'}), 400
                flash('Security session expired or invalid CSRF token. Please try again.', 'danger')
                return redirect(request.referrer or url_for('dashboard'))

    # -------------------------------------------------------------
    # Authentication Routes
    # -------------------------------------------------------------
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if 'user_id' in session:
            return redirect(url_for('dashboard'))

        if request.method == 'POST':
            username_or_email = request.form.get('username', '').strip()
            password = request.form.get('password', '').strip()

            if not username_or_email or not password:
                flash('Please enter both username/email and password.', 'danger')
                return render_template('auth/login.html', username=username_or_email)

            db = get_db()
            cur = db.cursor()
            cur.execute("""
                SELECT id, username, email, password_hash, full_name, role
                FROM users
                WHERE username = ? OR email = ?
            """, (username_or_email, username_or_email))
            user = cur.fetchone()

            if user and verify_password(user['password_hash'], password):
                session.clear()
                session['user_id'] = user['id']
                session['username'] = user['username']
                session['full_name'] = user['full_name']
                session['role'] = user['role']
                generate_csrf_token()  # Fresh token for logged-in session

                flash(f'Welcome back, {user["full_name"]}!', 'success')
                next_url = request.args.get('next')
                if next_url and next_url.startswith('/'):
                    return redirect(next_url)
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid credentials. Please verify your username/email and password.', 'danger')
                return render_template('auth/login.html', username=username_or_email)

        return render_template('auth/login.html')

    @app.route('/logout')
    def logout():
        session.clear()
        flash('You have been logged out successfully.', 'info')
        return redirect(url_for('login'))

    # -------------------------------------------------------------
    # Dashboard Route
    # -------------------------------------------------------------
    @app.route('/')
    @app.route('/dashboard')
    @login_required
    def dashboard():
        db = get_db()
        cur = db.cursor()

        # Metrics
        cur.execute("SELECT COUNT(*) AS count FROM students")
        total_students = cur.fetchone()['count']

        cur.execute("SELECT COUNT(*) AS count FROM examinations")
        total_exams = cur.fetchone()['count']

        cur.execute("SELECT COUNT(*) AS count FROM rooms")
        total_rooms = cur.fetchone()['count']

        cur.execute("SELECT COALESCE(SUM(capacity), 0) AS total_capacity FROM rooms")
        total_seats_available = cur.fetchone()['total_capacity']

        # Total registered students across all exams
        cur.execute("SELECT COUNT(*) AS count FROM exam_registrations")
        total_registrations = cur.fetchone()['count']

        # Total allocated students across all exams
        cur.execute("SELECT COUNT(*) AS count FROM allocations")
        total_allocated = cur.fetchone()['count']

        total_unallocated = max(0, total_registrations - total_allocated)

        # Upcoming examinations with registration and allocation counts
        cur.execute("""
            SELECT 
                e.id, e.exam_name, e.exam_code, e.subject, e.department, 
                e.exam_date, e.start_time, e.end_time, e.session,
                (SELECT COUNT(*) FROM exam_registrations er WHERE er.exam_id = e.id) AS registered_count,
                (SELECT COUNT(*) FROM allocations a WHERE a.exam_id = e.id) AS allocated_count
            FROM examinations e
            ORDER BY e.exam_date ASC, e.start_time ASC
            LIMIT 5
        """)
        upcoming_exams = [dict(r) for r in cur.fetchall()]

        # Recent allocation activity
        cur.execute("""
            SELECT ar.id, ar.exam_id, ar.total_registered, ar.total_allocated, ar.total_unallocated, 
                   ar.rooms_used, ar.run_at, e.exam_name, e.exam_code
            FROM allocation_runs ar
            JOIN examinations e ON ar.exam_id = e.id
            ORDER BY ar.run_at DESC
            LIMIT 5
        """)
        recent_activity = [dict(r) for r in cur.fetchall()]

        # Room occupancy breakdown
        cur.execute("""
            SELECT 
                r.id, r.room_name, r.room_number, r.building, r.capacity,
                (SELECT COUNT(DISTINCT a.seat_number) FROM allocations a WHERE a.room_id = r.id) AS current_occupied
            FROM rooms r
            ORDER BY r.room_number ASC
        """)
        rooms_occupancy = []
        for r in cur.fetchall():
            item = dict(r)
            cap = item['capacity']
            occ = item['current_occupied']
            item['occupancy_rate'] = round((occ / cap * 100), 1) if cap > 0 else 0
            rooms_occupancy.append(item)

        # Department distribution of students
        cur.execute("""
            SELECT department, COUNT(*) AS count 
            FROM students 
            GROUP BY department 
            ORDER BY count DESC
        """)
        dept_distribution = [dict(r) for r in cur.fetchall()]

        return render_template(
            'dashboard.html',
            total_students=total_students,
            total_exams=total_exams,
            total_rooms=total_rooms,
            total_seats_available=total_seats_available,
            total_allocated=total_allocated,
            total_unallocated=total_unallocated,
            total_registrations=total_registrations,
            upcoming_exams=upcoming_exams,
            recent_activity=recent_activity,
            rooms_occupancy=rooms_occupancy,
            dept_distribution=dept_distribution
        )

    # -------------------------------------------------------------
    # Students Management Routes
    # -------------------------------------------------------------
    @app.route('/students')
    @login_required
    def students_list():
        db = get_db()
        cur = db.cursor()

        q = request.args.get('q', '').strip()
        dept = request.args.get('department', '').strip()
        course = request.args.get('course', '').strip()
        semester = request.args.get('semester', '').strip()

        query = """
            SELECT s.id, s.roll_no, s.name, s.email, s.department, s.course, s.semester, s.created_at,
                   (SELECT COUNT(*) FROM exam_registrations er WHERE er.student_id = s.id) AS registered_exams_count,
                   (SELECT COUNT(*) FROM allocations a WHERE a.student_id = s.id) AS allocated_seats_count
            FROM students s
            WHERE 1=1
        """
        params = []

        if q:
            query += " AND (s.roll_no LIKE ? OR s.name LIKE ? OR s.email LIKE ?)"
            wildcard = f"%{q}%"
            params.extend([wildcard, wildcard, wildcard])
        if dept:
            query += " AND s.department = ?"
            params.append(dept)
        if course:
            query += " AND s.course = ?"
            params.append(course)
        if semester:
            query += " AND s.semester = ?"
            params.append(semester)

        query += " ORDER BY s.roll_no ASC"
        cur.execute(query, params)
        students = [dict(r) for r in cur.fetchall()]

        # Filter option lists
        cur.execute("SELECT DISTINCT department FROM students WHERE department IS NOT NULL AND department != '' ORDER BY department")
        departments = [r['department'] for r in cur.fetchall()]

        cur.execute("SELECT DISTINCT course FROM students WHERE course IS NOT NULL AND course != '' ORDER BY course")
        courses = [r['course'] for r in cur.fetchall()]

        cur.execute("SELECT DISTINCT semester FROM students WHERE semester IS NOT NULL ORDER BY semester")
        semesters = [r['semester'] for r in cur.fetchall()]

        return render_template(
            'students/index.html',
            students=students,
            departments=departments,
            courses=courses,
            semesters=semesters,
            search_query=q,
            selected_dept=dept,
            selected_course=course,
            selected_sem=semester,
            total_count=len(students)
        )

    @app.route('/students/add', methods=['POST'])
    @login_required
    def student_add():
        roll_no = request.form.get('roll_no', '').strip().upper()
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        department = request.form.get('department', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', '').strip()

        # Validation
        if not roll_no or not name or not department or not course or not semester:
            flash('All required fields (Roll Number, Name, Department, Course, Semester) must be filled.', 'danger')
            return redirect(url_for('students_list'))

        try:
            sem_int = int(semester)
            if sem_int <= 0 or sem_int > 12:
                flash('Semester must be an integer between 1 and 12.', 'danger')
                return redirect(url_for('students_list'))
        except ValueError:
            flash('Semester must be a valid integer.', 'danger')
            return redirect(url_for('students_list'))

        db = get_db()
        cur = db.cursor()

        # Check unique roll number
        cur.execute("SELECT id FROM students WHERE LOWER(roll_no) = LOWER(?)", (roll_no,))
        if cur.fetchone():
            flash(f"Error: A student with Roll Number '{roll_no}' already exists. Roll numbers must be unique.", 'danger')
            return redirect(url_for('students_list'))

        try:
            cur.execute("""
                INSERT INTO students (roll_no, name, email, department, course, semester)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (roll_no, name, email or None, department, course, sem_int))
            db.commit()
            flash(f"Student '{name}' ({roll_no}) added successfully!", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Failed to add student: {str(e)}", 'danger')

        return redirect(url_for('students_list'))

    @app.route('/students/edit/<int:id>', methods=['POST'])
    @login_required
    def student_edit(id):
        roll_no = request.form.get('roll_no', '').strip().upper()
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        department = request.form.get('department', '').strip()
        course = request.form.get('course', '').strip()
        semester = request.form.get('semester', '').strip()

        if not roll_no or not name or not department or not course or not semester:
            flash('All required fields must be filled.', 'danger')
            return redirect(url_for('students_list'))

        try:
            sem_int = int(semester)
        except ValueError:
            flash('Semester must be a valid number.', 'danger')
            return redirect(url_for('students_list'))

        db = get_db()
        cur = db.cursor()

        # Verify roll number uniqueness excluding current student
        cur.execute("SELECT id FROM students WHERE LOWER(roll_no) = LOWER(?) AND id != ?", (roll_no, id))
        if cur.fetchone():
            flash(f"Error: Another student already has Roll Number '{roll_no}'.", 'danger')
            return redirect(url_for('students_list'))

        try:
            cur.execute("""
                UPDATE students
                SET roll_no = ?, name = ?, email = ?, department = ?, course = ?, semester = ?
                WHERE id = ?
            """, (roll_no, name, email or None, department, course, sem_int, id))
            db.commit()
            flash(f"Student '{name}' updated successfully!", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Failed to update student: {str(e)}", 'danger')

        return redirect(url_for('students_list'))

    @app.route('/students/delete/<int:id>', methods=['POST'])
    @login_required
    def student_delete(id):
        db = get_db()
        cur = db.cursor()
        cur.execute("SELECT roll_no, name FROM students WHERE id = ?", (id,))
        student = cur.fetchone()
        if not student:
            flash('Student not found.', 'danger')
            return redirect(url_for('students_list'))

        try:
            # Cascades registrations and allocations due to schema foreign keys
            cur.execute("DELETE FROM students WHERE id = ?", (id,))
            db.commit()
            flash(f"Student '{student['name']}' ({student['roll_no']}) was successfully deleted.", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Could not delete student: {str(e)}", 'danger')

        return redirect(url_for('students_list'))

    # -------------------------------------------------------------
    # Examinations Management Routes
    # -------------------------------------------------------------
    @app.route('/examinations')
    @login_required
    def examinations_list():
        db = get_db()
        cur = db.cursor()

        q = request.args.get('q', '').strip()
        dept = request.args.get('department', '').strip()
        date_filter = request.args.get('date', '').strip()

        query = """
            SELECT 
                e.id, e.exam_name, e.exam_code, e.subject, e.department, 
                e.exam_date, e.start_time, e.end_time, e.session, e.created_at,
                (SELECT COUNT(*) FROM exam_registrations er WHERE er.exam_id = e.id) AS registered_count,
                (SELECT COUNT(*) FROM allocations a WHERE a.exam_id = e.id) AS allocated_count
            FROM examinations e
            WHERE 1=1
        """
        params = []
        if q:
            query += " AND (e.exam_name LIKE ? OR e.exam_code LIKE ? OR e.subject LIKE ?)"
            wildcard = f"%{q}%"
            params.extend([wildcard, wildcard, wildcard])
        if dept:
            query += " AND e.department = ?"
            params.append(dept)
        if date_filter:
            query += " AND e.exam_date = ?"
            params.append(date_filter)

        query += " ORDER BY e.exam_date ASC, e.start_time ASC"
        cur.execute(query, params)
        exams = [dict(r) for r in cur.fetchall()]

        # Departments list for filter
        cur.execute("SELECT DISTINCT department FROM examinations ORDER BY department")
        departments = [r['department'] for r in cur.fetchall()]

        return render_template(
            'examinations/index.html',
            exams=exams,
            departments=departments,
            search_query=q,
            selected_dept=dept,
            selected_date=date_filter,
            total_count=len(exams)
        )

    @app.route('/examinations/add', methods=['POST'])
    @login_required
    def examination_add():
        exam_name = request.form.get('exam_name', '').strip()
        exam_code = request.form.get('exam_code', '').strip().upper()
        subject = request.form.get('subject', '').strip()
        department = request.form.get('department', '').strip()
        exam_date = request.form.get('exam_date', '').strip()
        start_time = request.form.get('start_time', '').strip()
        end_time = request.form.get('end_time', '').strip()
        session_val = request.form.get('session', 'Morning').strip()

        if not exam_name or not exam_code or not subject or not department or not exam_date or not start_time or not end_time:
            flash('All examination fields are required.', 'danger')
            return redirect(url_for('examinations_list'))

        db = get_db()
        cur = db.cursor()

        # Check unique exam_code
        cur.execute("SELECT id FROM examinations WHERE LOWER(exam_code) = LOWER(?)", (exam_code,))
        if cur.fetchone():
            flash(f"Error: An examination with code '{exam_code}' already exists.", 'danger')
            return redirect(url_for('examinations_list'))

        try:
            cur.execute("""
                INSERT INTO examinations (exam_name, exam_code, subject, department, exam_date, start_time, end_time, session)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (exam_name, exam_code, subject, department, exam_date, start_time, end_time, session_val))
            db.commit()
            flash(f"Examination '{exam_name}' ({exam_code}) created successfully!", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Failed to create examination: {str(e)}", 'danger')

        return redirect(url_for('examinations_list'))

    @app.route('/examinations/edit/<int:id>', methods=['POST'])
    @login_required
    def examination_edit(id):
        exam_name = request.form.get('exam_name', '').strip()
        exam_code = request.form.get('exam_code', '').strip().upper()
        subject = request.form.get('subject', '').strip()
        department = request.form.get('department', '').strip()
        exam_date = request.form.get('exam_date', '').strip()
        start_time = request.form.get('start_time', '').strip()
        end_time = request.form.get('end_time', '').strip()
        session_val = request.form.get('session', 'Morning').strip()

        if not exam_name or not exam_code or not subject or not department or not exam_date or not start_time or not end_time:
            flash('All examination fields are required.', 'danger')
            return redirect(url_for('examinations_list'))

        db = get_db()
        cur = db.cursor()

        # Check unique code
        cur.execute("SELECT id FROM examinations WHERE LOWER(exam_code) = LOWER(?) AND id != ?", (exam_code, id))
        if cur.fetchone():
            flash(f"Error: Another exam already uses code '{exam_code}'.", 'danger')
            return redirect(url_for('examinations_list'))

        try:
            cur.execute("""
                UPDATE examinations
                SET exam_name = ?, exam_code = ?, subject = ?, department = ?, 
                    exam_date = ?, start_time = ?, end_time = ?, session = ?
                WHERE id = ?
            """, (exam_name, exam_code, subject, department, exam_date, start_time, end_time, session_val, id))
            db.commit()
            flash(f"Examination '{exam_name}' updated successfully!", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Failed to update examination: {str(e)}", 'danger')

        return redirect(url_for('examinations_list'))

    @app.route('/examinations/delete/<int:id>', methods=['POST'])
    @login_required
    def examination_delete(id):
        db = get_db()
        cur = db.cursor()
        cur.execute("SELECT exam_name, exam_code FROM examinations WHERE id = ?", (id,))
        exam = cur.fetchone()
        if not exam:
            flash('Examination not found.', 'danger')
            return redirect(url_for('examinations_list'))

        try:
            # Foreign keys cascade allocations, registrations, and runs
            cur.execute("DELETE FROM examinations WHERE id = ?", (id,))
            db.commit()
            flash(f"Examination '{exam['exam_name']}' ({exam['exam_code']}) deleted successfully.", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Could not delete examination: {str(e)}", 'danger')

        return redirect(url_for('examinations_list'))

    @app.route('/examinations/<int:id>')
    @login_required
    def examination_detail(id):
        db = get_db()
        cur = db.cursor()

        cur.execute("SELECT * FROM examinations WHERE id = ?", (id,))
        exam = cur.fetchone()
        if not exam:
            flash('Examination not found.', 'danger')
            return redirect(url_for('examinations_list'))

        # Registered students
        cur.execute("""
            SELECT s.id, s.roll_no, s.name, s.department, s.course, s.semester,
                   a.seat_label, r.room_name, r.room_number
            FROM exam_registrations er
            JOIN students s ON er.student_id = s.id
            LEFT JOIN allocations a ON (a.exam_id = er.exam_id AND a.student_id = s.id)
            LEFT JOIN rooms r ON a.room_id = r.id
            WHERE er.exam_id = ?
            ORDER BY s.roll_no ASC
        """, (id,))
        registered_students = [dict(r) for r in cur.fetchall()]

        # All available students who are NOT registered yet (for registration dropdown/modal)
        cur.execute("""
            SELECT s.id, s.roll_no, s.name, s.department, s.course, s.semester
            FROM students s
            WHERE s.id NOT IN (SELECT student_id FROM exam_registrations WHERE exam_id = ?)
            ORDER BY s.roll_no ASC
        """, (id,))
        unregistered_students = [dict(r) for r in cur.fetchall()]

        # Distinct departments of unregistered students for bulk enroll
        cur.execute("""
            SELECT DISTINCT department FROM students ORDER BY department
        """)
        all_departments = [r['department'] for r in cur.fetchall()]

        # Rooms allocated for this exam
        cur.execute("""
            SELECT r.id, r.room_name, r.room_number, r.capacity, COUNT(a.id) as allocated_count
            FROM allocations a
            JOIN rooms r ON a.room_id = r.id
            WHERE a.exam_id = ?
            GROUP BY r.id
            ORDER BY r.room_number ASC
        """, (id,))
        allocated_rooms = [dict(r) for r in cur.fetchall()]

        return render_template(
            'examinations/detail.html',
            exam=dict(exam),
            registered_students=registered_students,
            unregistered_students=unregistered_students,
            all_departments=all_departments,
            allocated_rooms=allocated_rooms
        )

    @app.route('/examinations/<int:id>/register', methods=['POST'])
    @login_required
    def examination_register_students(id):
        action_type = request.form.get('action_type', 'individual')
        db = get_db()
        cur = db.cursor()

        try:
            if action_type == 'bulk_dept':
                dept = request.form.get('department', '').strip()
                if not dept:
                    flash('Please select a department for bulk enrollment.', 'warning')
                    return redirect(url_for('examination_detail', id=id))

                cur.execute("""
                    INSERT OR IGNORE INTO exam_registrations (exam_id, student_id)
                    SELECT ?, id FROM students WHERE department = ?
                """, (id, dept))
                enrolled_count = cur.rowcount
                db.commit()
                flash(f"Enrolled {enrolled_count} student(s) from department '{dept}'.", 'success')

            elif action_type == 'individual':
                student_ids = request.form.getlist('student_ids')
                if not student_ids:
                    flash('No students selected for registration.', 'warning')
                    return redirect(url_for('examination_detail', id=id))

                for sid in student_ids:
                    cur.execute("""
                        INSERT OR IGNORE INTO exam_registrations (exam_id, student_id)
                        VALUES (?, ?)
                    """, (id, int(sid)))
                db.commit()
                flash(f"Registered {len(student_ids)} student(s) successfully.", 'success')

        except Exception as e:
            db.rollback()
            flash(f"Registration error: {str(e)}", 'danger')

        return redirect(url_for('examination_detail', id=id))

    @app.route('/examinations/<int:id>/unregister/<int:student_id>', methods=['POST'])
    @login_required
    def examination_unregister_student(id, student_id):
        db = get_db()
        cur = db.cursor()
        try:
            cur.execute("DELETE FROM exam_registrations WHERE exam_id = ? AND student_id = ?", (id, student_id))
            cur.execute("DELETE FROM allocations WHERE exam_id = ? AND student_id = ?", (id, student_id))
            db.commit()
            flash('Student unregistered from examination.', 'success')
        except Exception as e:
            db.rollback()
            flash(f"Could not unregister student: {str(e)}", 'danger')

        return redirect(url_for('examination_detail', id=id))

    # -------------------------------------------------------------
    # Examination Rooms Management Routes
    # -------------------------------------------------------------
    @app.route('/rooms')
    @login_required
    def rooms_list():
        db = get_db()
        cur = db.cursor()

        q = request.args.get('q', '').strip()
        building_filter = request.args.get('building', '').strip()

        query = """
            SELECT 
                r.id, r.room_name, r.room_number, r.building, r.floor, 
                r.capacity, r.rows_count, r.cols_count, r.created_at,
                (SELECT COUNT(DISTINCT a.id) FROM allocations a WHERE a.room_id = r.id) AS active_allocations_count
            FROM rooms r
            WHERE 1=1
        """
        params = []
        if q:
            query += " AND (r.room_name LIKE ? OR r.room_number LIKE ? OR r.building LIKE ?)"
            wildcard = f"%{q}%"
            params.extend([wildcard, wildcard, wildcard])
        if building_filter:
            query += " AND r.building = ?"
            params.append(building_filter)

        query += " ORDER BY r.room_number ASC"
        cur.execute(query, params)
        rooms = [dict(r) for r in cur.fetchall()]

        # Buildings list
        cur.execute("SELECT DISTINCT building FROM rooms ORDER BY building")
        buildings = [r['building'] for r in cur.fetchall()]

        return render_template(
            'rooms/index.html',
            rooms=rooms,
            buildings=buildings,
            search_query=q,
            selected_building=building_filter,
            total_count=len(rooms)
        )

    @app.route('/rooms/add', methods=['POST'])
    @login_required
    def room_add():
        room_name = request.form.get('room_name', '').strip()
        room_number = request.form.get('room_number', '').strip().upper()
        building = request.form.get('building', '').strip()
        floor = request.form.get('floor', '1').strip()
        capacity = request.form.get('capacity', '').strip()
        rows_count = request.form.get('rows_count', '5').strip()
        cols_count = request.form.get('cols_count', '6').strip()

        if not room_name or not room_number or not building or not capacity:
            flash('Room Name, Number, Building, and Capacity are required.', 'danger')
            return redirect(url_for('rooms_list'))

        try:
            cap_int = int(capacity)
            fl_int = int(floor)
            r_int = int(rows_count)
            c_int = int(cols_count)
            if cap_int <= 0 or r_int <= 0 or c_int <= 0:
                flash('Capacity, rows, and columns must be positive numbers greater than 0.', 'danger')
                return redirect(url_for('rooms_list'))
        except ValueError:
            flash('Capacity, floor, rows, and columns must be valid numbers.', 'danger')
            return redirect(url_for('rooms_list'))

        db = get_db()
        cur = db.cursor()

        # Check unique room number
        cur.execute("SELECT id FROM rooms WHERE LOWER(room_number) = LOWER(?)", (room_number,))
        if cur.fetchone():
            flash(f"Error: A room with number '{room_number}' already exists.", 'danger')
            return redirect(url_for('rooms_list'))

        try:
            cur.execute("""
                INSERT INTO rooms (room_name, room_number, building, floor, capacity, rows_count, cols_count)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (room_name, room_number, building, fl_int, cap_int, r_int, c_int))
            db.commit()
            flash(f"Room '{room_name}' ({room_number}) with capacity {cap_int} added successfully!", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Failed to add room: {str(e)}", 'danger')

        return redirect(url_for('rooms_list'))

    @app.route('/rooms/edit/<int:id>', methods=['POST'])
    @login_required
    def room_edit(id):
        room_name = request.form.get('room_name', '').strip()
        room_number = request.form.get('room_number', '').strip().upper()
        building = request.form.get('building', '').strip()
        floor = request.form.get('floor', '1').strip()
        capacity = request.form.get('capacity', '').strip()
        rows_count = request.form.get('rows_count', '5').strip()
        cols_count = request.form.get('cols_count', '6').strip()

        if not room_name or not room_number or not building or not capacity:
            flash('All room fields are required.', 'danger')
            return redirect(url_for('rooms_list'))

        try:
            cap_int = int(capacity)
            fl_int = int(floor)
            r_int = int(rows_count)
            c_int = int(cols_count)
            if cap_int <= 0 or r_int <= 0 or c_int <= 0:
                flash('Capacity, rows, and columns must be greater than 0.', 'danger')
                return redirect(url_for('rooms_list'))
        except ValueError:
            flash('Numeric fields must contain valid integers.', 'danger')
            return redirect(url_for('rooms_list'))

        db = get_db()
        cur = db.cursor()

        # Check unique room number
        cur.execute("SELECT id FROM rooms WHERE LOWER(room_number) = LOWER(?) AND id != ?", (room_number, id))
        if cur.fetchone():
            flash(f"Error: Another room already has number '{room_number}'.", 'danger')
            return redirect(url_for('rooms_list'))

        try:
            cur.execute("""
                UPDATE rooms
                SET room_name = ?, room_number = ?, building = ?, floor = ?, 
                    capacity = ?, rows_count = ?, cols_count = ?
                WHERE id = ?
            """, (room_name, room_number, building, fl_int, cap_int, r_int, c_int, id))
            db.commit()
            flash(f"Room '{room_name}' updated successfully!", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Failed to update room: {str(e)}", 'danger')

        return redirect(url_for('rooms_list'))

    @app.route('/rooms/delete/<int:id>', methods=['POST'])
    @login_required
    def room_delete(id):
        db = get_db()
        cur = db.cursor()

        # Strict safety check requirement:
        # Administrators can delete rooms ONLY when there are NO active allocations
        cur.execute("""
            SELECT r.room_name, r.room_number, COUNT(a.id) AS active_allocations
            FROM rooms r
            LEFT JOIN allocations a ON r.id = a.room_id
            WHERE r.id = ?
            GROUP BY r.id
        """, (id,))
        room = cur.fetchone()

        if not room:
            flash('Room not found.', 'danger')
            return redirect(url_for('rooms_list'))

        if room['active_allocations'] > 0:
            flash(
                f"Security Protection: Cannot delete Room '{room['room_name']}' ({room['room_number']}) "
                f"because it currently has {room['active_allocations']} active seat allocation(s). "
                f"Please clear or reassign exam allocations before deleting this room.",
                'danger'
            )
            return redirect(url_for('rooms_list'))

        try:
            cur.execute("DELETE FROM rooms WHERE id = ?", (id,))
            db.commit()
            flash(f"Room '{room['room_name']}' ({room['room_number']}) was successfully deleted.", 'success')
        except Exception as e:
            db.rollback()
            flash(f"Could not delete room: {str(e)}", 'danger')

        return redirect(url_for('rooms_list'))

    # -------------------------------------------------------------
    # Seat Allocation Module Routes
    # -------------------------------------------------------------
    @app.route('/allocate', methods=['GET', 'POST'])
    @login_required
    def seat_allocation():
        db = get_db()
        cur = db.cursor()

        # Fetch all examinations
        cur.execute("""
            SELECT e.id, e.exam_name, e.exam_code, e.subject, e.exam_date, e.session, e.start_time, e.end_time,
                   (SELECT COUNT(*) FROM exam_registrations er WHERE er.exam_id = e.id) AS registered_count,
                   (SELECT COUNT(*) FROM allocations a WHERE a.exam_id = e.id) AS allocated_count
            FROM examinations e
            ORDER BY e.exam_date ASC, e.start_time ASC
        """)
        exams = [dict(r) for r in cur.fetchall()]

        # Fetch all available rooms
        cur.execute("SELECT id, room_name, room_number, building, floor, capacity FROM rooms ORDER BY room_number ASC")
        rooms = [dict(r) for r in cur.fetchall()]

        selected_exam_id = request.args.get('exam_id', type=int)
        if not selected_exam_id and exams:
            selected_exam_id = exams[0]['id']

        # Get preview data for selected exam
        preview_data = None
        current_allocations_summary = None
        if selected_exam_id:
            cur.execute("SELECT * FROM examinations WHERE id = ?", (selected_exam_id,))
            current_exam = cur.fetchone()

            # Room selection for preview
            room_ids = request.args.getlist('room_ids', type=int)
            if not room_ids:
                room_ids = [r['id'] for r in rooms]  # default all rooms

            preview_data = allocation_engine.get_exam_allocation_preview(db, selected_exam_id, room_ids)

            # Check if this exam has existing allocations
            cur.execute("""
                SELECT 
                    a.id, a.seat_label, a.seat_number, s.roll_no, s.name, s.department, s.course,
                    r.room_name, r.room_number
                FROM allocations a
                JOIN students s ON a.student_id = s.id
                JOIN rooms r ON a.room_id = r.id
                WHERE a.exam_id = ?
                ORDER BY r.room_number ASC, a.seat_number ASC
            """, (selected_exam_id,))
            current_allocations = [dict(r) for r in cur.fetchall()]

            if current_allocations:
                # Group by room
                rooms_breakdown = {}
                for a in current_allocations:
                    rname = a['room_name']
                    if rname not in rooms_breakdown:
                        rooms_breakdown[rname] = {'count': 0, 'room_number': a['room_number']}
                    rooms_breakdown[rname]['count'] += 1

                current_allocations_summary = {
                    'count': len(current_allocations),
                    'rooms_breakdown': rooms_breakdown,
                    'sample_allocations': current_allocations[:10]
                }

        # Handling POST to execute allocation
        if request.method == 'POST':
            exam_id = request.form.get('exam_id', type=int)
            room_ids = [int(x) for x in request.form.getlist('room_ids') if x.isdigit()]
            confirm_overwrite = request.form.get('confirm_overwrite') == 'yes'

            if not exam_id:
                flash('Please select an examination.', 'danger')
                return redirect(url_for('seat_allocation'))

            if not room_ids:
                flash('Please select at least one examination room.', 'danger')
                return redirect(url_for('seat_allocation', exam_id=exam_id))

            try:
                result = allocation_engine.execute_allocation(
                    db,
                    exam_id=exam_id,
                    room_ids=room_ids,
                    allow_overwrite=confirm_overwrite
                )
                
                flash(
                    f"Successfully generated seating plan for '{result['exam_name']}'! "
                    f"Allocated {result['total_allocated']} student(s) across {len([r for r in result['rooms_summary'] if r['allocated_count'] > 0])} room(s).",
                    'success'
                )

                if result['total_unallocated'] > 0:
                    flash(
                        f"Notice: {result['total_unallocated']} student(s) could not be allocated due to insufficient room capacity. "
                        f"Please assign additional rooms or view the Unallocated Students Report.",
                        'warning'
                    )

                return render_template(
                    'allocation/index.html',
                    exams=exams,
                    rooms=rooms,
                    selected_exam_id=exam_id,
                    selected_room_ids=room_ids,
                    preview_data=preview_data,
                    allocation_result=result,
                    current_allocations_summary=current_allocations_summary
                )

            except allocation_engine.AllocationConflictError as ace:
                flash(str(ace), 'warning')
                # Re-render with prompt to confirm overwrite
                return render_template(
                    'allocation/index.html',
                    exams=exams,
                    rooms=rooms,
                    selected_exam_id=exam_id,
                    selected_room_ids=room_ids,
                    preview_data=preview_data,
                    requires_overwrite_confirmation=True,
                    conflict_message=str(ace),
                    current_allocations_summary=current_allocations_summary
                )
            except allocation_engine.AllocationError as ae:
                flash(str(ae), 'danger')
                return redirect(url_for('seat_allocation', exam_id=exam_id))

        return render_template(
            'allocation/index.html',
            exams=exams,
            rooms=rooms,
            selected_exam_id=selected_exam_id,
            selected_room_ids=room_ids if selected_exam_id else [r['id'] for r in rooms],
            preview_data=preview_data,
            current_allocations_summary=current_allocations_summary
        )

    @app.route('/allocate/clear/<int:exam_id>', methods=['POST'])
    @login_required
    def clear_exam_allocations(exam_id):
        db = get_db()
        cur = db.cursor()
        try:
            cur.execute("SELECT exam_name FROM examinations WHERE id = ?", (exam_id,))
            exam = cur.fetchone()
            cur.execute("DELETE FROM allocations WHERE exam_id = ?", (exam_id,))
            cur.execute("DELETE FROM allocation_runs WHERE exam_id = ?", (exam_id,))
            db.commit()
            flash(f"Allocations cleared for '{exam['exam_name'] if exam else 'Exam'}'.", 'info')
        except Exception as e:
            db.rollback()
            flash(f"Error clearing allocations: {str(e)}", 'danger')

        return redirect(url_for('seat_allocation', exam_id=exam_id))

    # -------------------------------------------------------------
    # Seating Plan Visual Grid Routes
    # -------------------------------------------------------------
    @app.route('/seating-plan')
    @login_required
    def seating_plan():
        db = get_db()
        cur = db.cursor()

        # All exams with allocations
        cur.execute("""
            SELECT DISTINCT e.id, e.exam_name, e.exam_code, e.subject, e.exam_date, e.session
            FROM examinations e
            JOIN allocations a ON e.id = a.exam_id
            ORDER BY e.exam_date ASC
        """)
        exams_with_allocations = [dict(r) for r in cur.fetchall()]

        # All exams for dropdown (including those without allocations)
        cur.execute("SELECT id, exam_name, exam_code FROM examinations ORDER BY exam_date ASC")
        all_exams = [dict(r) for r in cur.fetchall()]

        selected_exam_id = request.args.get('exam_id', type=int)
        if not selected_exam_id:
            if exams_with_allocations:
                selected_exam_id = exams_with_allocations[0]['id']
            elif all_exams:
                selected_exam_id = all_exams[0]['id']

        # Rooms allocated for this exam
        rooms_for_exam = []
        if selected_exam_id:
            cur.execute("""
                SELECT DISTINCT r.id, r.room_name, r.room_number, r.capacity,
                       (SELECT COUNT(*) FROM allocations a WHERE a.exam_id = ? AND a.room_id = r.id) as allocated_count
                FROM rooms r
                JOIN allocations a ON r.id = a.room_id
                WHERE a.exam_id = ?
                ORDER BY r.room_number ASC
            """, (selected_exam_id, selected_exam_id))
            rooms_for_exam = [dict(r) for r in cur.fetchall()]

            # If no rooms are allocated yet, show all rooms in system for reference
            if not rooms_for_exam:
                cur.execute("SELECT id, room_name, room_number, capacity, 0 as allocated_count FROM rooms ORDER BY room_number ASC")
                rooms_for_exam = [dict(r) for r in cur.fetchall()]

        selected_room_id = request.args.get('room_id', type=int)
        if not selected_room_id and rooms_for_exam:
            selected_room_id = rooms_for_exam[0]['id']

        # Selected Exam details
        selected_exam = None
        if selected_exam_id:
            cur.execute("SELECT * FROM examinations WHERE id = ?", (selected_exam_id,))
            exam_row = cur.fetchone()
            if exam_row:
                selected_exam = dict(exam_row)

        # Build matrix
        matrix_data = None
        if selected_exam_id and selected_room_id:
            matrix_data = allocation_engine.get_seating_matrix(db, selected_exam_id, selected_room_id)

        return render_template(
            'seating_plan/index.html',
            all_exams=all_exams,
            exams_with_allocations=exams_with_allocations,
            rooms_for_exam=rooms_for_exam,
            selected_exam=selected_exam,
            selected_exam_id=selected_exam_id,
            selected_room_id=selected_room_id,
            matrix_data=matrix_data
        )

    # -------------------------------------------------------------
    # Find My Seat (Public / Student Portal)
    # -------------------------------------------------------------
    @app.route('/find-my-seat')
    def find_my_seat():
        db = get_db()
        cur = db.cursor()

        query = request.args.get('q', '').strip()
        results = []
        has_searched = bool(query)

        if query:
            wildcard = f"%{query}%"
            cur.execute("""
                SELECT 
                    s.id AS student_id, s.roll_no, s.name AS student_name, s.department AS student_dept, s.course, s.semester,
                    e.id AS exam_id, e.exam_name, e.exam_code, e.subject, e.exam_date, e.start_time, e.end_time, e.session,
                    r.id AS room_id, r.room_name, r.room_number, r.building, r.floor,
                    a.seat_number, a.seat_label, a.allocated_at
                FROM allocations a
                JOIN students s ON a.student_id = s.id
                JOIN examinations e ON a.exam_id = e.id
                JOIN rooms r ON a.room_id = r.id
                WHERE (s.roll_no LIKE ? OR s.name LIKE ? OR e.exam_name LIKE ? OR e.exam_code LIKE ? OR e.subject LIKE ?)
                ORDER BY e.exam_date ASC, s.roll_no ASC
            """, (wildcard, wildcard, wildcard, wildcard, wildcard))
            results = [dict(r) for r in cur.fetchall()]

        # Latest published exams for quick student reference
        cur.execute("""
            SELECT e.exam_name, e.exam_code, e.subject, e.exam_date, e.start_time, e.session
            FROM examinations e
            WHERE (SELECT COUNT(*) FROM allocations a WHERE a.exam_id = e.id) > 0
            ORDER BY e.exam_date ASC
            LIMIT 4
        """)
        active_exams = [dict(r) for r in cur.fetchall()]

        return render_template(
            'find_seat/index.html',
            search_query=query,
            has_searched=has_searched,
            results=results,
            active_exams=active_exams
        )

    # -------------------------------------------------------------
    # Reports and CSV Export Routes
    # -------------------------------------------------------------
    @app.route('/reports')
    @login_required
    def reports():
        db = get_db()
        cur = db.cursor()

        exam_id = request.args.get('exam_id', type=int)
        room_id = request.args.get('room_id', type=int)
        view_type = request.args.get('view', 'complete')  # 'complete', 'room', 'student', 'unallocated'

        # Exams dropdown
        cur.execute("SELECT id, exam_name, exam_code, exam_date FROM examinations ORDER BY exam_date ASC")
        exams = [dict(r) for r in cur.fetchall()]
        if not exam_id and exams:
            exam_id = exams[0]['id']

        # Rooms dropdown
        cur.execute("SELECT id, room_name, room_number FROM rooms ORDER BY room_number ASC")
        rooms = [dict(r) for r in cur.fetchall()]

        # Selected Exam details
        selected_exam = None
        if exam_id:
            cur.execute("SELECT * FROM examinations WHERE id = ?", (exam_id,))
            row = cur.fetchone()
            if row:
                selected_exam = dict(row)

        # Selected Room details
        selected_room = None
        if room_id:
            cur.execute("SELECT * FROM rooms WHERE id = ?", (room_id,))
            row = cur.fetchone()
            if row:
                selected_room = dict(row)

        # Allocations query based on filters
        allocations_data = []
        unallocated_data = []

        if exam_id:
            # Main allocations query
            base_query = """
                SELECT 
                    a.id, a.seat_label, a.seat_number,
                    s.roll_no, s.name AS student_name, s.department AS student_dept, s.course, s.semester,
                    e.exam_name, e.exam_code, e.subject, e.exam_date, e.start_time, e.end_time, e.session,
                    r.room_name, r.room_number, r.building, r.floor
                FROM allocations a
                JOIN students s ON a.student_id = s.id
                JOIN examinations e ON a.exam_id = e.id
                JOIN rooms r ON a.room_id = r.id
                WHERE a.exam_id = ?
            """
            params = [exam_id]

            if room_id:
                base_query += " AND a.room_id = ?"
                params.append(room_id)

            base_query += " ORDER BY r.room_number ASC, a.seat_number ASC, s.roll_no ASC"
            cur.execute(base_query, params)
            allocations_data = [dict(r) for r in cur.fetchall()]

            # Unallocated students query (registered for this exam, but no seat in allocations)
            cur.execute("""
                SELECT s.id, s.roll_no, s.name, s.department, s.course, s.semester
                FROM students s
                JOIN exam_registrations er ON s.id = er.student_id
                WHERE er.exam_id = ? 
                  AND s.id NOT IN (SELECT student_id FROM allocations WHERE exam_id = ?)
                ORDER BY s.roll_no ASC
            """, (exam_id, exam_id))
            unallocated_data = [dict(r) for r in cur.fetchall()]

        # Summary statistics for this report
        report_summary = {
            'total_registered': len(allocations_data) + len(unallocated_data),
            'total_allocated': len(allocations_data),
            'total_unallocated': len(unallocated_data)
        }

        return render_template(
            'reports/index.html',
            exams=exams,
            rooms=rooms,
            selected_exam=selected_exam,
            selected_exam_id=exam_id,
            selected_room=selected_room,
            selected_room_id=room_id,
            view_type=view_type,
            allocations=allocations_data,
            unallocated=unallocated_data,
            report_summary=report_summary
        )

    @app.route('/reports/export/csv')
    @login_required
    def export_csv():
        db = get_db()
        cur = db.cursor()

        exam_id = request.args.get('exam_id', type=int)
        room_id = request.args.get('room_id', type=int)

        query = """
            SELECT 
                s.roll_no, s.name AS student_name, s.department, s.course, s.semester,
                e.exam_name, e.exam_code, e.subject, e.exam_date, e.session, e.start_time, e.end_time,
                r.room_name, r.room_number, r.building, a.seat_number, a.seat_label, a.allocated_at
            FROM allocations a
            JOIN students s ON a.student_id = s.id
            JOIN examinations e ON a.exam_id = e.id
            JOIN rooms r ON a.room_id = r.id
            WHERE 1=1
        """
        params = []
        if exam_id:
            query += " AND a.exam_id = ?"
            params.append(exam_id)
        if room_id:
            query += " AND a.room_id = ?"
            params.append(room_id)

        query += " ORDER BY e.exam_date ASC, r.room_number ASC, a.seat_number ASC, s.roll_no ASC"
        cur.execute(query, params)
        rows = cur.fetchall()

        # Generate CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            'Roll Number', 'Student Name', 'Department', 'Course', 'Semester',
            'Exam Name', 'Exam Code', 'Subject', 'Date', 'Session', 'Start Time', 'End Time',
            'Room Name', 'Room Number', 'Building', 'Seat Number', 'Seat Label', 'Allocated At'
        ])

        for r in rows:
            writer.writerow([
                r['roll_no'], r['student_name'], r['department'], r['course'], r['semester'],
                r['exam_name'], r['exam_code'], r['subject'], r['exam_date'], r['session'], r['start_time'], r['end_time'],
                r['room_name'], r['room_number'], r['building'], r['seat_number'], r['seat_label'], r['allocated_at']
            ])

        response = make_response(output.getvalue())
        filename = f"ExamSeat_Allocations_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        response.headers['Content-Disposition'] = f"attachment; filename={filename}"
        response.headers['Content-Type'] = 'text/csv; charset=utf-8'
        return response

    # -------------------------------------------------------------
    # Settings & Administration Routes
    # -------------------------------------------------------------
    @app.route('/settings')
    @login_required
    def settings_page():
        db = get_db()
        cur = db.cursor()

        # Administrator record
        cur.execute("SELECT id, username, email, full_name FROM users WHERE id = ?", (session['user_id'],))
        user = dict(cur.fetchone())

        # System settings
        cur.execute("SELECT key, value FROM system_settings")
        settings_dict = {r['key']: r['value'] for r in cur.fetchall()}

        # Database statistics
        cur.execute("SELECT COUNT(*) AS c FROM students")
        sc = cur.fetchone()['c']
        cur.execute("SELECT COUNT(*) AS c FROM examinations")
        ec = cur.fetchone()['c']
        cur.execute("SELECT COUNT(*) AS c FROM rooms")
        rc = cur.fetchone()['c']
        cur.execute("SELECT COUNT(*) AS c FROM allocations")
        ac = cur.fetchone()['c']

        db_stats = {
            'students_count': sc,
            'exams_count': ec,
            'rooms_count': rc,
            'allocations_count': ac,
            'db_path': app.config.get('DATABASE')
        }

        return render_template('settings/index.html', user=user, settings=settings_dict, stats=db_stats)

    @app.route('/settings/profile', methods=['POST'])
    @login_required
    def update_profile():
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        current_password = request.form.get('current_password', '').strip()
        new_password = request.form.get('new_password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()

        if not full_name or not email:
            flash('Full Name and Email are required.', 'danger')
            return redirect(url_for('settings_page'))

        db = get_db()
        cur = db.cursor()
        cur.execute("SELECT password_hash FROM users WHERE id = ?", (session['user_id'],))
        user_row = cur.fetchone()

        # If updating password
        if new_password:
            if not current_password:
                flash('Current password is required to set a new password.', 'danger')
                return redirect(url_for('settings_page'))
            if not verify_password(user_row['password_hash'], current_password):
                flash('Incorrect current password.', 'danger')
                return redirect(url_for('settings_page'))
            if new_password != confirm_password:
                flash('New passwords do not match.', 'danger')
                return redirect(url_for('settings_page'))
            if len(new_password) < 6:
                flash('New password must be at least 6 characters long.', 'danger')
                return redirect(url_for('settings_page'))

            new_hash = hash_password(new_password)
            cur.execute("""
                UPDATE users SET full_name = ?, email = ?, password_hash = ? WHERE id = ?
            """, (full_name, email, new_hash, session['user_id']))
        else:
            cur.execute("""
                UPDATE users SET full_name = ?, email = ? WHERE id = ?
            """, (full_name, email, session['user_id']))

        db.commit()
        session['full_name'] = full_name
        flash('Administrator profile updated successfully!', 'success')
        return redirect(url_for('settings_page'))

    @app.route('/settings/institution', methods=['POST'])
    @login_required
    def update_institution_settings():
        institution_name = request.form.get('institution_name', '').strip()
        academic_year = request.form.get('academic_year', '').strip()
        exam_cycle = request.form.get('exam_cycle', '').strip()
        contact_email = request.form.get('contact_email', '').strip()
        contact_phone = request.form.get('contact_phone', '').strip()
        seating_policy = request.form.get('seating_policy', '').strip()

        db = get_db()
        cur = db.cursor()
        settings_pairs = [
            ('institution_name', institution_name),
            ('academic_year', academic_year),
            ('exam_cycle', exam_cycle),
            ('contact_email', contact_email),
            ('contact_phone', contact_phone),
            ('seating_policy', seating_policy)
        ]
        for k, v in settings_pairs:
            cur.execute("INSERT OR REPLACE INTO system_settings (key, value) VALUES (?, ?)", (k, v))
        db.commit()
        flash('Institutional settings saved successfully.', 'success')
        return redirect(url_for('settings_page'))

    @app.route('/settings/clear-allocations', methods=['POST'])
    @login_required
    def clear_all_allocations():
        db = get_db()
        cur = db.cursor()
        try:
            cur.execute("DELETE FROM allocations")
            cur.execute("DELETE FROM allocation_runs")
            db.commit()
            flash('All seating allocations have been cleared.', 'info')
        except Exception as e:
            db.rollback()
            flash(f"Error clearing allocations: {str(e)}", 'danger')

        return redirect(url_for('settings_page'))

    @app.route('/settings/reload-sample-data', methods=['POST'])
    @login_required
    def reload_sample_data():
        try:
            seed_sample_data(app)
            flash('Sample demonstration data successfully loaded and re-seeded!', 'success')
        except Exception as e:
            flash(f"Error loading sample data: {str(e)}", 'danger')

        return redirect(url_for('settings_page'))

    @app.route('/settings/reset-database', methods=['POST'])
    @login_required
    def reset_database():
        confirm = request.form.get('confirm_reset')
        if confirm != 'CONFIRM':
            flash("Database reset aborted: You must type 'CONFIRM' to proceed.", 'warning')
            return redirect(url_for('settings_page'))

        try:
            init_db(app)
            seed_sample_data(app)
            flash('Database has been completely reset to fresh schema with initial seed data.', 'success')
        except Exception as e:
            flash(f"Error resetting database: {str(e)}", 'danger')

        return redirect(url_for('settings_page'))

    # -------------------------------------------------------------
    # Error Handlers
    # -------------------------------------------------------------
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('base.html', not_found_error=True), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template('base.html', server_error=True), 500

    return app

if __name__ == '__main__':
    app = create_app()
    print("=" * 60)
    print(" ExamSeat - Modern Examination Seat Allocation System")
    print(" Running locally at: http://127.0.0.1:5000")
    print(" Default Admin Credentials: admin / admin123")
    print("=" * 60)
    app.run(debug=True, host='127.0.0.1', port=5000)

/**
 * ExamSeat UI Helper Scripts
 */
document.addEventListener('DOMContentLoaded', function () {
  // 1. Password show/hide toggler
  document.querySelectorAll('.password-toggle-btn').forEach(function (button) {
    button.addEventListener('click', function () {
      const targetId = this.getAttribute('data-target');
      const input = document.getElementById(targetId);
      const icon = this.querySelector('i');
      if (input) {
        if (input.type === 'password') {
          input.type = 'text';
          icon.classList.remove('fa-eye');
          icon.classList.add('fa-eye-slash');
        } else {
          input.type = 'password';
          icon.classList.remove('fa-eye-slash');
          icon.classList.add('fa-eye');
        }
      }
    });
  });

  // 2. Mobile Sidebar Toggle
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('appSidebar');
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', function () {
      sidebar.classList.toggle('show');
    });
  }

  // 3. Auto-dismiss alerts after 6 seconds
  setTimeout(function () {
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function (alert) {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      if (bsAlert) {
        bsAlert.close();
      }
    });
  }, 6000);

  // 4. Live Room Selection Capacity Counter (for /allocate page)
  const roomCheckboxes = document.querySelectorAll('.room-checkbox');
  const totalCapacityDisplay = document.getElementById('totalSelectedCapacity');
  const capacityStatusBadge = document.getElementById('capacityStatusBadge');
  const registeredCountEl = document.getElementById('registeredStudentsCount');

  function updateAllocationCapacitySummary() {
    if (!totalCapacityDisplay) return;

    let totalCap = 0;
    let selectedCount = 0;
    roomCheckboxes.forEach(function (cb) {
      if (cb.checked) {
        totalCap += parseInt(cb.getAttribute('data-capacity') || '0', 10);
        selectedCount++;
      }
    });

    totalCapacityDisplay.textContent = totalCap;

    if (registeredCountEl && capacityStatusBadge) {
      const regCount = parseInt(registeredCountEl.textContent || '0', 10);
      if (selectedCount === 0) {
        capacityStatusBadge.className = 'badge bg-secondary';
        capacityStatusBadge.textContent = 'No rooms selected';
      } else if (totalCap >= regCount) {
        capacityStatusBadge.className = 'badge bg-success';
        capacityStatusBadge.textContent = `Sufficient (+${totalCap - regCount} surplus seats)`;
      } else {
        const deficit = regCount - totalCap;
        capacityStatusBadge.className = 'badge bg-danger';
        capacityStatusBadge.textContent = `Deficit: ${deficit} student(s) unallocated`;
      }
    }
  }

  if (roomCheckboxes.length > 0) {
    roomCheckboxes.forEach(function (cb) {
      cb.addEventListener('change', updateAllocationCapacitySummary);
    });
    updateAllocationCapacitySummary();

    // Select All / Deselect All rooms helper
    const selectAllBtn = document.getElementById('selectAllRooms');
    const deselectAllBtn = document.getElementById('deselectAllRooms');
    if (selectAllBtn) {
      selectAllBtn.addEventListener('click', function () {
        roomCheckboxes.forEach(cb => cb.checked = true);
        updateAllocationCapacitySummary();
      });
    }
    if (deselectAllBtn) {
      deselectAllBtn.addEventListener('click', function () {
        roomCheckboxes.forEach(cb => cb.checked = false);
        updateAllocationCapacitySummary();
      });
    }
  }

  // 5. Interactive Desk Seat Tooltips / Modal Viewer on Seating Plan
  const seatCards = document.querySelectorAll('.desk-occupied');
  const modalStudentRoll = document.getElementById('modalStudentRoll');
  const modalStudentName = document.getElementById('modalStudentName');
  const modalStudentDept = document.getElementById('modalStudentDept');
  const modalStudentSeat = document.getElementById('modalStudentSeat');
  const seatModalEl = document.getElementById('seatDetailModal');

  if (seatCards.length > 0 && seatModalEl) {
    const seatModal = new bootstrap.Modal(seatModalEl);
    seatCards.forEach(function (card) {
      card.addEventListener('click', function () {
        const roll = this.getAttribute('data-roll');
        const name = this.getAttribute('data-name');
        const dept = this.getAttribute('data-dept');
        const seat = this.getAttribute('data-seat');

        if (modalStudentRoll) modalStudentRoll.textContent = roll;
        if (modalStudentName) modalStudentName.textContent = name;
        if (modalStudentDept) modalStudentDept.textContent = dept;
        if (modalStudentSeat) modalStudentSeat.textContent = seat;

        seatModal.show();
      });
    });
  }

  // 6. Generic Confirmation Modal helper for destructive forms
  document.querySelectorAll('.btn-confirm-delete').forEach(function (button) {
    button.addEventListener('click', function (e) {
      const entityName = this.getAttribute('data-name') || 'this item';
      if (!confirm(`Are you sure you want to permanently delete "${entityName}"? This action cannot be undone.`)) {
        e.preventDefault();
      }
    });
  });
});

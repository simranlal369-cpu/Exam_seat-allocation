# Exam Seat Allocation System
# A simple console-based program using basic Python concepts: lists, dictionaries, loops, if/else, and functions.

# List to store all student records as dictionaries: {"roll_no": ..., "name": ...}
students = []

# List to store all room details as dictionaries: {"room_name": ..., "capacity": ...}
rooms = []

# List to store final seat allocation records: {"roll_no": ..., "name": ..., "room_name": ..., "seat_no": ...}
allocations = []


# Function 1: Add a new student to the system
def add_student():
    print("\n--- Add New Student ---")
    
    # Taking roll number input from user and removing leading/trailing spaces
    roll_no = input("Enter Roll Number: ").strip()
    
    # Checking if roll number is empty
    if roll_no == "":
        print("Error: Roll number cannot be empty!")
        return
    
    # Checking if a student with the same roll number already exists
    for student in students:
        if student["roll_no"].lower() == roll_no.lower():
            print("Error: A student with this Roll Number already exists!")
            return
            
    # Taking student name input
    name = input("Enter Student Name: ").strip()
    
    # Checking if student name is empty
    if name == "":
        print("Error: Student name cannot be empty!")
        return
        
    # Creating a student record using a dictionary
    new_student = {
        "roll_no": roll_no,
        "name": name
    }
    
    # Adding the student dictionary to the students list
    students.append(new_student)
    print(f"Success: Student '{name}' (Roll No: {roll_no}) added successfully!")


# Function 2: Add a new room with seat capacity
def add_room():
    print("\n--- Add New Room ---")
    
    # Taking room name/number input
    room_name = input("Enter Room Name or Number: ").strip()
    
    # Checking if room name is empty
    if room_name == "":
        print("Error: Room name cannot be empty!")
        return
        
    # Checking if room already exists
    for room in rooms:
        if room["room_name"].lower() == room_name.lower():
            print("Error: A room with this Name/Number already exists!")
            return
            
    # Taking capacity input
    capacity_input = input("Enter Room Capacity (number of seats): ").strip()
    
    # Validating that capacity is a positive number
    if not capacity_input.isdigit() or int(capacity_input) <= 0:
        print("Error: Capacity must be a positive integer!")
        return
        
    capacity = int(capacity_input)
    
    # Creating a room record using a dictionary
    new_room = {
        "room_name": room_name,
        "capacity": capacity
    }
    
    # Adding the room dictionary to the rooms list
    rooms.append(new_room)
    print(f"Success: Room '{room_name}' with capacity {capacity} added successfully!")


# Function 3: Allocate seats to students in available rooms
def allocate_seats():
    print("\n--- Allocate Seats ---")
    
    # Checking if there are any students
    if len(students) == 0:
        print("Error: No students found. Please add students first!")
        return
        
    # Checking if there are any rooms
    if len(rooms) == 0:
        print("Error: No rooms found. Please add rooms first!")
        return
        
    # Clear previous allocations before fresh allocation
    allocations.clear()
    
    # student_index tracks which student is being assigned next
    student_index = 0
    total_students = len(students)
    
    # Outer loop: go through each room one by one
    for room in rooms:
        room_name = room["room_name"]
        capacity = room["capacity"]
        
        # Inner loop: assign seat numbers from 1 up to room capacity
        for seat_no in range(1, capacity + 1):
            
            # Check if there are still students left to allocate
            if student_index < total_students:
                current_student = students[student_index]
                
                # Create allocation record mapping student to room and seat
                allocation_record = {
                    "roll_no": current_student["roll_no"],
                    "name": current_student["name"],
                    "room_name": room_name,
                    "seat_no": seat_no
                }
                
                # Add record to allocations list
                allocations.append(allocation_record)
                
                # Move to next student
                student_index = student_index + 1
            else:
                # All students are allocated, break inner loop
                break
                
        # If all students are allocated, break outer loop
        if student_index >= total_students:
            break
            
    # Print summary of allocation
    print(f"Success: Allocated seats for {len(allocations)} out of {total_students} student(s).")
    
    # Warning if rooms were not enough for all students
    if student_index < total_students:
        unallocated_count = total_students - student_index
        print(f"Notice: {unallocated_count} student(s) could not get seats due to lack of room capacity.")


# Function 4: Display all allocated seats in a neat table format
def show_allocation():
    print("\n--- Current Seat Allocations ---")
    
    # Check if seat allocation has been performed
    if len(allocations) == 0:
        print("No allocations found. Please run 'Allocate Seats' first!")
        return
        
    # Print table header
    print("=" * 65)
    print(f"{'Roll No':<15} {'Student Name':<20} {'Room':<15} {'Seat No':<10}")
    print("-" * 65)
    
    # Loop through each allocation record and print in table rows
    for item in allocations:
        print(f"{item['roll_no']:<15} {item['name']:<20} {item['room_name']:<15} {item['seat_no']:<10}")
        
    print("=" * 65)


# Function 5: Search allocation details for a specific student using Roll Number
def search_student():
    print("\n--- Search Student by Roll Number ---")
    
    # Check if seat allocation has been performed
    if len(allocations) == 0:
        print("No allocations found. Please run 'Allocate Seats' first!")
        return
        
    # Ask user for roll number to search
    search_roll = input("Enter Roll Number to search: ").strip()
    
    # Flag variable to track whether student was found
    found = False
    
    # Loop through all allocation records to find matching roll number
    for item in allocations:
        if item["roll_no"].lower() == search_roll.lower():
            print("\n>>> Student Seat Details Found <<<")
            print(f"Roll Number : {item['roll_no']}")
            print(f"Name        : {item['name']}")
            print(f"Room Name   : {item['room_name']}")
            print(f"Seat Number : {item['seat_no']}")
            found = True
            break  # Stop searching once match is found
            
    # If loop finished and student was not found
    if not found:
        print(f"No seat allocation found for Roll Number: '{search_roll}'")


# Main function to run the menu-driven system
def main():
    # Infinite loop to keep the menu running until user chooses exit
    while True:
        print("\n==========================================")
        print("      EXAM SEAT ALLOCATION SYSTEM        ")
        print("==========================================")
        print("1. Add Student")
        print("2. Add Room")
        print("3. Allocate Seats")
        print("4. Show Allocation")
        print("5. Search Student by Roll Number")
        print("6. Exit")
        print("==========================================")
        
        # Take menu choice input from user
        choice = input("Enter your choice (1-6): ").strip()
        
        # Check user choice and call corresponding function
        if choice == "1":
            add_student()
        elif choice == "2":
            add_room()
        elif choice == "3":
            allocate_seats()
        elif choice == "4":
            show_allocation()
        elif choice == "5":
            search_student()
        elif choice == "6":
            print("\nThank you for using Exam Seat Allocation System. Exiting...")
            break  # Exit the while loop to terminate program
        else:
            print("Invalid choice! Please select a valid number from 1 to 6.")


# Starting point of the program execution
if __name__ == "__main__":
    main()

import os
import sqlite3
from flask import g, current_app
from werkzeug.security import generate_password_hash
from config import BASE_DIR, Config

def get_db():
    """Get database connection for current request context."""
    if 'db' not in g:
        db_path = current_app.config.get('DATABASE', Config.DATABASE)
        g.db = sqlite3.connect(db_path)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON;")
    return g.db

def close_db(e=None):
    """Close database connection."""
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db(app=None):
    """Initialize database tables from schema.sql."""
    db_path = app.config.get('DATABASE', Config.DATABASE) if app else Config.DATABASE
    schema_path = os.path.join(BASE_DIR, 'schema.sql')
    
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    with open(schema_path, 'r', encoding='utf-8') as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()

def seed_sample_data(app=None):
    """Seed comprehensive sample data for demonstration."""
    db_path = app.config.get('DATABASE', Config.DATABASE) if app else Config.DATABASE
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    cur = conn.cursor()

    # 1. Default Administrator
    cur.execute("SELECT id FROM users WHERE username = ?", ('admin',))
    if not cur.fetchone():
        admin_hash = generate_password_hash('admin123')
        cur.execute("""
            INSERT INTO users (username, email, password_hash, full_name, role)
            VALUES (?, ?, ?, ?, ?)
        """, ('admin', 'admin@examseat.edu', admin_hash, 'Dr. Rajesh Sharma (Controller of Exams)', 'admin'))

    # 2. System Settings
    settings = [
        ('institution_name', 'Apex Institute of Technology & Science'),
        ('academic_year', '2026 - 2027'),
        ('exam_cycle', 'End Semester Examination - Autumn 2026'),
        ('contact_email', 'exams@apex.edu'),
        ('contact_phone', '+91 98765 43210'),
        ('seating_policy', 'Roll Number Sequential with Alternate Desk spacing')
    ]
    for k, v in settings:
        cur.execute("INSERT OR REPLACE INTO system_settings (key, value) VALUES (?, ?)", (k, v))

    # 3. Sample Rooms
    rooms_data = [
        ('Lecture Hall A101', 'A-101', 'Block A (Main Wing)', 1, 20, 4, 5),
        ('Classroom A102', 'A-102', 'Block A (Main Wing)', 1, 15, 3, 5),
        ('Lecture Hall B201', 'B-201', 'Block B (Science Wing)', 2, 24, 4, 6),
        ('Seminar Room B202', 'B-202', 'Block B (Science Wing)', 2, 12, 3, 4),
        ('Central Auditorium', 'AUD-1', 'Central Complex', 1, 40, 5, 8),
        ('Drawing Hall D301', 'D-301', 'Design & Technology Wing', 3, 18, 3, 6),
    ]
    for r in rooms_data:
        cur.execute("SELECT id FROM rooms WHERE room_number = ?", (r[1],))
        if not cur.fetchone():
            cur.execute("""
                INSERT INTO rooms (room_name, room_number, building, floor, capacity, rows_count, cols_count)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, r)

    # 4. Sample Students (35 students across departments)
    students_data = [
        ('2026CS101', 'Aarav Patel', 'aarav.patel@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS102', 'Ananya Sharma', 'ananya.sharma@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS103', 'Rohan Gupta', 'rohan.gupta@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS104', 'Sneha Iyer', 'sneha.iyer@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS105', 'Vikram Aditya', 'vikram.aditya@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS106', 'Priya Nair', 'priya.nair@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS107', 'Kunal Verma', 'kunal.verma@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS108', 'Diya Sen', 'diya.sen@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS109', 'Siddharth Rao', 'siddharth.rao@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS110', 'Neha Choudhury', 'neha.choudhury@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS111', 'Arjun Kapoor', 'arjun.kapoor@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS112', 'Tanvi Deshmukh', 'tanvi.deshmukh@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS113', 'Manish Reddy', 'manish.reddy@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS114', 'Ritu Saxena', 'ritu.saxena@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS115', 'Aditya Joshi', 'aditya.joshi@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS116', 'Ishita Mehra', 'ishita.mehra@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS117', 'Gaurav Bhat', 'gaurav.bhat@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS118', 'Pooja Hegde', 'pooja.hegde@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS119', 'Naveen Kumar', 'naveen.kumar@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS120', 'Kavya Menon', 'kavya.menon@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS121', 'Devansh Pillai', 'devansh.pillai@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS122', 'Swati Das', 'swati.das@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS123', 'Varun Malhotra', 'varun.malhotra@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS124', 'Simran Kaur', 'simran.kaur@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026CS125', 'Harsh Singhal', 'harsh.singhal@apex.edu', 'Computer Science', 'B.Tech CSE', 4),
        ('2026IT201', 'Aakash Roy', 'aakash.roy@apex.edu', 'Information Technology', 'B.Tech IT', 6),
        ('2026IT202', 'Bhavna Kulkarni', 'bhavna.k@apex.edu', 'Information Technology', 'B.Tech IT', 6),
        ('2026IT203', 'Chetan Pandey', 'chetan.pandey@apex.edu', 'Information Technology', 'B.Tech IT', 6),
        ('2026IT204', 'Deepa Mishra', 'deepa.mishra@apex.edu', 'Information Technology', 'B.Tech IT', 6),
        ('2026IT205', 'Farhan Ali', 'farhan.ali@apex.edu', 'Information Technology', 'B.Tech IT', 6),
        ('2026EC301', 'Geeta Nambiar', 'geeta.nambiar@apex.edu', 'Electronics & Comm', 'B.Tech ECE', 4),
        ('2026EC302', 'Himanshu Tyagi', 'himanshu.tyagi@apex.edu', 'Electronics & Comm', 'B.Tech ECE', 4),
        ('2026EC303', 'Jyoti Bansal', 'jyoti.bansal@apex.edu', 'Electronics & Comm', 'B.Tech ECE', 4),
        ('2026ME401', 'Karan Johar', 'karan.johar@apex.edu', 'Mechanical Engineering', 'B.Tech ME', 6),
        ('2026ME402', 'Lata Rawat', 'lata.rawat@apex.edu', 'Mechanical Engineering', 'B.Tech ME', 6),
    ]
    for s in students_data:
        cur.execute("SELECT id FROM students WHERE roll_no = ?", (s[0],))
        if not cur.fetchone():
            cur.execute("""
                INSERT INTO students (roll_no, name, email, department, course, semester)
                VALUES (?, ?, ?, ?, ?, ?)
            """, s)

    # 5. Sample Examinations
    exams_data = [
        ('CS401: Database Management Systems', 'CS401-2026', 'Database Management Systems', 'Computer Science', '2026-11-10', '09:30', '12:30', 'Morning'),
        ('IT502: Computer Networks & Security', 'IT502-2026', 'Computer Networks & Security', 'Information Technology', '2026-11-12', '14:00', '17:00', 'Afternoon'),
        ('EC301: Digital Signal Processing', 'EC301-2026', 'Digital Signal Processing', 'Electronics & Comm', '2026-11-14', '09:30', '12:30', 'Morning'),
        ('ME405: Thermodynamics & Fluid Flow', 'ME405-2026', 'Thermodynamics & Fluid Flow', 'Mechanical Engineering', '2026-11-16', '14:00', '17:00', 'Afternoon'),
    ]
    for e in exams_data:
        cur.execute("SELECT id FROM examinations WHERE exam_code = ?", (e[1],))
        if not cur.fetchone():
            cur.execute("""
                INSERT INTO examinations (exam_name, exam_code, subject, department, exam_date, start_time, end_time, session)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, e)

    conn.commit()

    # 6. Register Students to CS401 (all 25 CS students)
    cur.execute("SELECT id FROM examinations WHERE exam_code = 'CS401-2026'")
    exam_row = cur.fetchone()
    if exam_row:
        exam_id = exam_row['id']
        cur.execute("SELECT id FROM students WHERE department = 'Computer Science'")
        cs_students = cur.fetchall()
        for st in cs_students:
            cur.execute("""
                INSERT OR IGNORE INTO exam_registrations (exam_id, student_id)
                VALUES (?, ?)
            """, (exam_id, st['id']))

        # Also register IT students to IT502
        cur.execute("SELECT id FROM examinations WHERE exam_code = 'IT502-2026'")
        it_exam = cur.fetchone()
        if it_exam:
            cur.execute("SELECT id FROM students WHERE department = 'Information Technology'")
            for st in cur.fetchall():
                cur.execute("INSERT OR IGNORE INTO exam_registrations (exam_id, student_id) VALUES (?, ?)", (it_exam['id'], st['id']))

        # Also register EC students to EC301
        cur.execute("SELECT id FROM examinations WHERE exam_code = 'EC301-2026'")
        ec_exam = cur.fetchone()
        if ec_exam:
            cur.execute("SELECT id FROM students WHERE department = 'Electronics & Comm'")
            for st in cur.fetchall():
                cur.execute("INSERT OR IGNORE INTO exam_registrations (exam_id, student_id) VALUES (?, ?)", (ec_exam['id'], st['id']))

        # Register ME students to ME405
        cur.execute("SELECT id FROM examinations WHERE exam_code = 'ME405-2026'")
        me_exam = cur.fetchone()
        if me_exam:
            cur.execute("SELECT id FROM students WHERE department = 'Mechanical Engineering'")
            for st in cur.fetchall():
                cur.execute("INSERT OR IGNORE INTO exam_registrations (exam_id, student_id) VALUES (?, ?)", (me_exam['id'], st['id']))

        conn.commit()

        # 7. Pre-seed allocation for CS401 across Room A-101 (cap: 20) and Room A-102 (cap: 15)
        # Check if allocations already exist for CS401
        cur.execute("SELECT COUNT(*) AS cnt FROM allocations WHERE exam_id = ?", (exam_id,))
        if cur.fetchone()['cnt'] == 0:
            # Fetch rooms A-101 and A-102
            cur.execute("SELECT id, room_number, capacity FROM rooms WHERE room_number IN ('A-101', 'A-102') ORDER BY room_number ASC")
            alloc_rooms = cur.fetchall()
            
            # Fetch CS registered students ordered by roll_no
            cur.execute("""
                SELECT s.id, s.roll_no 
                FROM students s
                JOIN exam_registrations er ON s.id = er.student_id
                WHERE er.exam_id = ?
                ORDER BY s.roll_no ASC
            """, (exam_id,))
            reg_students = cur.fetchall()

            std_idx = 0
            total_allocated = 0
            rooms_used_names = []

            for r in alloc_rooms:
                rooms_used_names.append(r['room_number'])
                cap = r['capacity']
                for seat_num in range(1, cap + 1):
                    if std_idx < len(reg_students):
                        st = reg_students[std_idx]
                        seat_label = f"{r['room_number']}-{seat_num:02d}"
                        cur.execute("""
                            INSERT INTO allocations (exam_id, student_id, room_id, seat_number, seat_label)
                            VALUES (?, ?, ?, ?, ?)
                        """, (exam_id, st['id'], r['id'], seat_num, seat_label))
                        std_idx += 1
                        total_allocated += 1
                    else:
                        break
                if std_idx >= len(reg_students):
                    break

            # Log allocation run
            cur.execute("""
                INSERT INTO allocation_runs (exam_id, total_registered, total_allocated, total_unallocated, rooms_used)
                VALUES (?, ?, ?, ?, ?)
            """, (exam_id, len(reg_students), total_allocated, len(reg_students) - total_allocated, ", ".join(rooms_used_names)))
            conn.commit()

    conn.close()

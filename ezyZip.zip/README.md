# ExamSeat — Automated Examination Seat Allocation & Management System

> **A modern, secure, and production-grade Web Application for Academic Examination Seating, Hall Logistics, and Real-Time Seat Allocation.**

[![Python](https://img.shields.io/badge/Python-3.10%20%7C%203.11%20%7C%203.12-blue.svg)](https://www.python.org/)
[![Flask](https://img.shields.io/badge/Flask-3.1.3-green.svg)](https://palletsprojects.com/p/flask/)
[![SQLite](https://img.shields.io/badge/SQLite-3-lightgrey.svg)](https://www.sqlite.org/)
[![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3.3-purple.svg)](https://getbootstrap.com/)
[![Tests](https://img.shields.io/badge/Tests-8%20Passed%20(100%25)-brightgreen.svg)]()

---

## Table of Contents
1. [Executive Summary & Features](#executive-summary--features)
2. [Technology Stack](#technology-stack)
3. [System Architecture & Database Schema](#system-architecture--database-schema)
4. [Project Directory & File Structure](#project-directory--file-structure)
5. [Installation & Setup Guide](#installation--setup-guide)
6. [Starting the Application & Browser Access](#starting-the-application--browser-access)
7. [Default Administrative Credentials](#default-administrative-credentials)
8. [Comprehensive Teacher Demonstration Workflow](#comprehensive-teacher-demonstration-workflow)
9. [Seat Allocation Algorithm & Mechanics](#seat-allocation-algorithm--mechanics)
10. [Security & Defensive Architecture](#security--defensive-architecture)
11. [Automated Verification & Unit Testing](#automated-verification--unit-testing)
12. [Troubleshooting & FAQ](#troubleshooting--faq)

---

## Executive Summary & Features

**ExamSeat** is an end-to-end examination seat allocation and hall invigilation platform engineered for colleges, universities, and certification testing centers. Manual examination seating arrangements often suffer from administrative bottlenecks, accidental double-allocations, uneven room utilization, roll-number collisions, and lack of real-time student visibility. 

ExamSeat resolves these challenges by providing:
- **Responsive Web Dashboard**: Real-time KPI statistics loaded dynamically from SQLite, Chart.js visual analytics (Allocated vs. Unallocated), room occupancy progress meters, upcoming schedules, and recent run history.
- **Role-Based Security**: Cryptographic password hashing (Werkzeug PBKDF2/scrypt), session-level CSRF token verification across all state-changing endpoints, SQL injection immunity via parameterized queries, and show/hide password controls.
- **Candidate Registry (Students Module)**: Full student lifecycle management with server-side validation, unique roll-number enforcement, and multi-criteria filtering by Department, Academic Course, and Semester.
- **Venues & Examination Schedules**: Full room inventory tracking (Building, Floor, Capacity, Matrix dimensions) protected by strict allocation guardrails preventing premature deletion of active halls.
- **Algorithmic Seat Generator**: Sequential roll-number sorting across selected venues, deterministic unique seat labelling (`ROOM-SEAT`), capacity shortfall warnings, and overwrite conflict protection requiring explicit confirmation.
- **Interactive 2D Seating Plan**: Visual room matrix representing real desk positions with color-coded states (Occupied vs. Vacant), candidate identification tooltips, and printable blackboard layouts.
- **Public Candidate Portal (Find My Seat)**: Instant lookup by Roll Number, Candidate Name, or Subject Code, presenting room numbers, buildings, floors, and seat labels.
- **Invigilator Reports & Data Export**: Complete master rosters, room-wise attendance sheets with physical signature lines, unallocated candidate reports, and one-click CSV export downloads.

---

## Technology Stack

- **Backend Framework**: Python 3.12, Flask 3.1.3 (Application Factory pattern)
- **Database Engine**: SQLite 3 with WAL journal mode, explicit foreign key constraints (`PRAGMA foreign_keys = ON;`), and transactional commits
- **Authentication & Security**: Werkzeug Security (`generate_password_hash`, `check_password_hash`), Session-based tokens with HMAC-SHA256 constant-time verification
- **Frontend Framework**: Responsive HTML5, CSS3, JavaScript (ES6+), Bootstrap 5.3.3
- **Icons & Data Visualization**: Font Awesome 6.5.1, Chart.js 4.4.1, Google Fonts Inter
- **Reporting & Print Layout**: Specialized `@media print` CSS for A4 invigilator roll-call attendance sheets and RFC-4180 compliant CSV exports

---

## System Architecture & Database Schema

The application is structured around a relational SQLite data model guaranteeing referential integrity:

```
               +----------------------+
               |        users         |
               +----------------------+
               | id (PK)              |
               | username (UNIQUE)    |
               | password_hash        |
               +----------------------+
                          
   +--------------------+          +--------------------+
   |      students      |          |    examinations    |
   +--------------------+          +--------------------+
   | id (PK)            |          | id (PK)            |
   | roll_no (UNIQUE)   |          | exam_code (UNIQUE) |
   | name, email        |          | exam_date, session |
   | dept, course, sem  |          | start/end time     |
   +--------------------+          +--------------------+
             |                               |
             +---------------+---------------+
                             |
              +-----------------------------+
              |      exam_registrations     |
              +-----------------------------+
              | id (PK)                     |
              | exam_id (FK -> examinations)|
              | student_id (FK -> students) |
              | UNIQUE (exam_id, student_id)|
              +-----------------------------+
                             |
   +--------------------+    |
   |       rooms        |    |
   +--------------------+    |
   | id (PK)            |    |
   | room_number (UNQ)  |    |
   | capacity           |    |
   | rows_count, cols   |    |
   +--------------------+    |
             |               |
             +-------+-------+
                     |
         +-------------------------------------+
         |             allocations             |
         +-------------------------------------+
         | id (PK)                             |
         | exam_id (FK -> examinations)        |
         | student_id (FK -> students)         |
         | room_id (FK -> rooms RESTRICT)      |
         | seat_number (INT)                   |
         | seat_label (TEXT, e.g. 'A-101-01')  |
         | UNIQUE (exam_id, student_id)        |
         | UNIQUE (exam_id, room_id, seat_no)  |
         +-------------------------------------+
```

---

## Project Directory & File Structure

```
exam_project/
├── app.py                      # Flask Application Factory, route controllers, error handlers
├── config.py                   # Environment configuration, session lifetimes, database paths
├── database.py                 # SQLite connection lifecycle, schema initialization, sample data seeder
├── schema.sql                  # Relational database schema with foreign keys, checks, and indexes
├── auth.py                     # Authentication helpers, login_required decorator, CSRF engine
├── allocation_engine.py        # Core seat allocation algorithm, preview counter, seating matrix
├── test_system.py              # Automated test suite (8 test cases verifying 100% of workflows)
├── requirements.txt            # Python package dependencies
├── main.py                     # Initial standalone script (preserved)
├── static/
│   ├── css/
│   │   ├── style.css           # Custom modern UI design system, badges, desk representations
│   │   └── print.css           # Invigilator print stylesheet (A4 attendance sheets, signature blocks)
│   └── js/
│       └── main.js             # Password toggle, live room capacity counter, interactive seat tooltips
└── templates/
    ├── base.html               # Base layout with sidebar, navbar, flash messages, modal container
    ├── auth/
    │   └── login.html          # Administrator login portal with show/hide password control
    ├── dashboard.html          # Operational dashboard: 6 stat cards, Chart.js, room occupancy, upcoming exams
    ├── students/
    │   └── index.html          # Candidate registry: add, edit, delete, search, multi-filter
    ├── examinations/
    │   ├── index.html          # Exam list, scheduling, edit/delete modals
    │   └── detail.html         # Exam roster, enrolled students, bulk department enrollment
    ├── rooms/
    │   └── index.html          # Venues list, grid dimensions, strict allocation deletion guard
    ├── allocation/
    │   └── index.html          # Allocation wizard, live capacity calculator, overwrite prompt, summary
    ├── seating_plan/
    │   └── index.html          # 2D visual room grid, occupied/vacant desks, interactive candidate modal
    ├── find_seat/
    │   └── index.html          # Public student portal: instant seat lookup, hall passes, failure guidance
    ├── reports/
    │   └── index.html          # Master reports, room-wise attendance sheets, unallocated view, CSV export
    └── settings/
        └── index.html          # Admin profile, credentials, institutional parameters, demo reset tools
```

---

## Installation & Setup Guide

### 1. Prerequisites
- Python 3.10, 3.11, or 3.12 installed on your machine.
- Verify with `python --version` or `py --version`.

### 2. Virtual Environment Setup (Recommended)
Open a terminal in the project directory:

**Windows PowerShell:**
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

**macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
Install Flask and its required runtime packages:
```bash
pip install -r requirements.txt
```

---

## Starting the Application & Browser Access

### 1. Start the Flask Server
Run the application directly:
```bash
python app.py
```

You will see output confirming the server has launched:
```
============================================================
 ExamSeat - Modern Examination Seat Allocation System
 Running locally at: http://127.0.0.1:5000
 Default Admin Credentials: admin / admin123
============================================================
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://127.0.0.1:5000
```

### 2. Open in Your Web Browser
Open your browser and navigate to:
[http://127.0.0.1:5000](http://127.0.0.1:5000)

- If logged out, visiting `/` redirects to `/login`.
- The public candidate seat lookup is accessible at `/find-my-seat`.

---

## Default Administrative Credentials

| Parameter | Value |
| :--- | :--- |
| **Username** | `admin` |
| **Email** | `admin@examseat.edu` |
| **Password** | `admin123` |
| **Role** | System Administrator / Controller of Examinations |

> [!TIP]
> The database automatically initializes on first run and pre-seeds 35 students, 6 rooms, 4 examinations, and a demonstration allocation. You can reload or reset sample datasets anytime in **Settings** &rarr; **Database Maintenance**.

---

## Comprehensive Teacher Demonstration Workflow

Follow these step-by-step instructions for an end-to-end evaluation:

```
+-----------------------------------------------------------------------------------------+
|                               TEACHER DEMONSTRATION WORKFLOW                             |
+-----------------------------------------------------------------------------------------+
|  1. Login & Show/Hide Password  -->  2. Dashboard Live Metrics & Charts                  |
|                                       |                                                 |
|  4. Scheduling & Enrollment    <--  3. Student Registry, Search & Filtering            |
|       |                                                                                 |
|  5. Room Capacity Guardrails   -->  6. Live Seat Allocation Wizard                       |
|                                       |                                                 |
|  8. Invigilator Attendance Sheets <-- 7. Interactive 2D Seating Plan                   |
|       |                                                                                 |
|  9. Public Student Seat Finder  --> 10. Settings & Password Management                  |
+-----------------------------------------------------------------------------------------+
```

### Step 1: Administrator Authentication
1. Go to `http://127.0.0.1:5000/login`.
2. Test validation by submitting empty fields or an incorrect password &rarr; observe immediate warning alert.
3. Type `admin` and `admin123`. Click the **eye icon** in the password box to demonstrate the **Show/Hide Password** toggle.
4. Click **Sign In to Dashboard**.

### Step 2: Dashboard Overview & Real-Time KPIs
1. Notice the **6 Top KPI Cards**: Total Students, Examinations, Rooms, Seats Available, Allocated, and Unallocated.
2. Observe the **Allocated vs. Unallocated visual Doughnut Chart** powered by Chart.js.
3. Review the **Examination Rooms Occupancy Table** with utilization progress bars.
4. Notice the **Quick Action Center** buttons: every single button navigates to a functional route.

### Step 3: Student Management (Search & Multi-Filter)
1. Click **Students** in the sidebar (`/students`).
2. Demonstrate **Search**: Type `Aarav` in the search bar and press Enter &rarr; filters instantly to `2026CS101`.
3. Demonstrate **Department / Semester Filter**: Select `Information Technology` and click **Filter**.
4. Click **Add New Student**: Register a new student (e.g. Roll No `2026TEST01`, Name `Vikram Roy`, Dept `Computer Science`, Semester `4`).
5. Attempt adding another student with the **same roll number** &rarr; verify the database-level uniqueness error is reported cleanly.
6. Edit a student and verify changes persist.

### Step 4: Examinations & Student Registration Roster
1. Click **Examinations** (`/examinations`).
2. Click on the first examination: **CS401: Database Management Systems**.
3. View the roster of 25 enrolled students with their current allocated rooms and seats.
4. Demonstrate **Bulk Enrollment**: Click **Bulk Enroll by Department** and select a department to enroll students in one click.

### Step 5: Examination Rooms & Strict Deletion Protection
1. Click **Examination Rooms** (`/rooms`).
2. Inspect the venues: **Room A-101** (20 seats), **Room A-102** (15 seats), **Room B-201** (24 seats), etc.
3. Demonstrate the **Strict Security Deletion Guard**:
   - Attempt to delete **Room A-101** (which currently hosts active exam seats).
   - The application blocks deletion and displays an alert: *"Cannot delete Room because it currently has active seat allocations"*.
4. Click **Add New Room** to demonstrate adding a hall with custom rows and columns.

### Step 6: Automated Seat Allocation Generator
1. Click **Seat Allocation** (`/allocate`).
2. Select an exam: **IT502: Computer Networks & Security**.
3. Notice the live candidate counter: **5 Registered Students**.
4. Under **Step 2 (Select Rooms)**:
   - Check **Room B-202 (12 seats)**.
   - Observe the real-time JS badge: *"Sufficient (+7 surplus seats)"*.
   - Uncheck all rooms &rarr; badge turns grey: *"No rooms selected"*.
5. Select a room and click **Generate & Save Allocation**.
6. The system computes seat labels (e.g. `B-202-01`, `B-202-02`), logs the allocation run, and displays the room breakdown.
7. Click **Generate & Save Allocation** a second time &rarr; observe the **Overwrite Conflict Warning** requiring explicit checkbox confirmation before regeneration.

### Step 7: Interactive 2D Seating Plan Matrix
1. Click **Seating Plan** (`/seating-plan`).
2. Select **CS401** and **Room A-101**.
3. Observe the physical 2D layout:
   - **Front of Hall / Whiteboard Banner** representing classroom orientation.
   - **Green Desks (`desk-occupied`)** displaying seat labels (`A-101-01`), student roll numbers, and names.
   - **Dashed Desks (`desk-vacant`)** for empty positions.
   - **Visual Legend** showing Occupied vs. Vacant counts and percentage utilization.
4. Click any occupied green desk &rarr; opens an **interactive Candidate Allocation Modal** with full candidate details.

### Step 8: Reports, Invigilator Attendance Sheets & CSV Export
1. Click **Reports & Sheets** (`/reports`).
2. Switch between the 4 dedicated view modes:
   - **Complete Master Report**: Tabular overview of all seated candidates.
   - **Room-wise Attendance Sheet**: Formatted with student roll call rows and **blank Student Signature underlines**.
   - **Student-wise View**: Candidate-centric lookup table.
   - **Unallocated Students Report**: Highlights any students left without seats due to venue capacity deficits.
3. Click **Print Report Sheet**: Notice how navigation bars and buttons disappear, formatting an official A4 printout with invigilator verification signatures.
4. Click **Export Allocation CSV**: Downloads `ExamSeat_Allocations_<timestamp>.csv` containing all allocation metadata.

### Step 9: Public Candidate Portal (Find My Seat)
1. Click **Student Portal** in the top navbar or open `http://127.0.0.1:5000/find-my-seat`.
2. Search for Roll Number `2026CS101`.
3. View the student hall pass card displaying the assigned venue (**Room A-101**, Building A, Floor 1) and seat label (**A-101-01**).
4. Search for an unallocated student or invalid roll number &rarr; observe the clear troubleshooting alert box.

### Step 10: Settings, Security & Database Reset
1. Click **Settings** (`/settings`).
2. Update the Administrator profile or change the password.
3. View system diagnostics: total database records, SQLite path, and foreign key integrity.
4. Demonstrate **Reload Sample Data**: Resets demonstration data to default state with one click.

---

## Seat Allocation Algorithm & Mechanics

The seat allocation engine in [`allocation_engine.py`](file:///c:/Users/SIMRAN/OneDrive/Desktop/exam_project/allocation_engine.py) implements a deterministic greedy sequential mapping algorithm:

$$\text{Time Complexity: } \mathcal{O}(S \log S + \sum_{r \in R} C_r) \quad\text{where } S = |\text{Students}|, R = \text{Selected Rooms}, C_r = \text{Capacity of room } r$$

### Formal Algorithm Pseudocode
```
Algorithm: AllocateSeats(exam_id, room_ids, allow_overwrite)
Input: Examination ID, List of selected Room IDs, Overwrite Boolean
Output: Allocation Result Structure

1. Verify exam_id exists in database
2. Check existing allocations count for exam_id
3. IF existing_count > 0 AND allow_overwrite == FALSE THEN:
       RAISE AllocationConflictError("Overwrite confirmation required")
4. Fetch registered students:
       students = Query(SELECT student_id, roll_no FROM registrations WHERE exam_id ORDER BY roll_no ASC)
5. Fetch room capacities:
       rooms = Query(SELECT id, room_number, capacity FROM rooms WHERE id IN (room_ids) ORDER BY room_number ASC)
6. BEGIN TRANSACTION
7. IF existing_count > 0 AND allow_overwrite == TRUE THEN:
       Execute(DELETE FROM allocations WHERE exam_id = exam_id)
8. student_index = 0
9. FOR each room IN rooms:
       FOR seat_num FROM 1 TO room.capacity:
           IF student_index < length(students):
               st = students[student_index]
               seat_label = Format("{}-{}", room.room_number, PadLeft(seat_num, 2, '0'))
               Execute(INSERT INTO allocations (exam_id, student_id, room_id, seat_number, seat_label)
                       VALUES (exam_id, st.id, room.id, seat_num, seat_label))
               student_index = student_index + 1
           ELSE:
               BREAK inner loop
       IF student_index >= length(students):
           BREAK outer loop
10. unallocated_students = students[student_index:]
11. Execute(INSERT INTO allocation_runs (exam_id, registered, allocated, unallocated, rooms_used))
12. COMMIT TRANSACTION
13. RETURN Result(allocated_count, unallocated_students, rooms_summary)
```

---

## Security & Defensive Architecture

1. **Password Hashing**: Uses Werkzeug's adaptive salted PBKDF2/scrypt implementation (`werkzeug.security.generate_password_hash`). Passwords are never stored in plain text.
2. **CSRF Defense**: Cryptographic 32-byte tokens (`secrets.token_hex(32)`) stored in session and validated before every `POST`, `PUT`, `DELETE` request using constant-time string comparison (`hmac.compare_digest`).
3. **SQL Injection Prevention**: 100% of queries use parameterized prepared statements with `?` placeholders. No dynamic string concatenation is used in database operations.
4. **Relational Constraints**:
   - `UNIQUE (roll_no)` ensures no duplicate students.
   - `UNIQUE (exam_code)` ensures unique course identifiers.
   - `UNIQUE (exam_id, student_id)` strictly enforces that no student can have duplicate seats in the same exam.
   - `UNIQUE (exam_id, room_id, seat_number)` guarantees no two students are ever assigned to the same desk.
5. **Room Deletion Protection**: Before deleting any venue, the system executes an active allocation audit. If any exam is mapped to the room, deletion is blocked with a security alert.

---

## Automated Verification & Unit Testing

The test suite in [`test_system.py`](file:///c:/Users/SIMRAN/OneDrive/Desktop/exam_project/test_system.py) contains 8 test scenarios verifying all application specifications:

```bash
python test_system.py
```

### Test Suite Execution Output:
```
........
----------------------------------------------------------------------
Ran 8 tests in 2.693s

OK
```

### Tested Scenarios:
1. `test_database_initialization_and_seed`: Verifies table creation, admin hashing, sample students, rooms, exams, and default allocations.
2. `test_authentication_workflow`: Tests unauthorized redirection, invalid passwords, successful login, and session clearance on logout.
3. `test_csrf_protection`: Asserts that missing or invalid CSRF tokens are rejected.
4. `test_students_crud_and_uniqueness`: Asserts student insertion, edit, search, multi-filter, and rejects duplicate roll numbers.
5. `test_room_safety_and_deletion_guard`: Verifies that rooms with active seat allocations cannot be deleted.
6. `test_seat_allocation_and_seating_plan`: Tests the allocation engine, unique seat labels (`A-101-01`), overwrite confirmation, and visual seating matrix generation.
7. `test_find_my_seat_public_portal`: Verifies candidate seat lookup by roll number, name, and proper handling of no-allocation states.
8. `test_reports_and_csv_export`: Asserts generation of complete master reports, room-wise attendance sheets with signature blocks, and CSV downloads.

---

## Troubleshooting & FAQ

#### Q: How do I change the default port from 5000?
A: In `app.py`, update `app.run(port=5000)` to your desired port (e.g. `app.run(port=8080)`), or run:
```bash
flask run --port=8080
```

#### Q: Where is the SQLite database file stored?
A: The database file is located at `exam_project/examseat.db`. It is created automatically upon launching the application or running the test suite.

#### Q: Can I run ExamSeat on a local institutional network?
A: Yes! To make ExamSeat accessible to other computers on your college LAN or Wi-Fi, change `host='127.0.0.1'` to `host='0.0.0.0'` in `app.py`. Students and staff can then access it via `http://<your-ip-address>:5000`.

#### Q: How do I reset the entire system for a fresh semester?
A: Log in as administrator, navigate to **Settings**, scroll to **Database Maintenance**, type `CONFIRM`, and click **Reset DB**.

---

**Developed with precision for Academic Examination Excellence.**

-- ExamSeat Database Schema
PRAGMA foreign_keys = ON;

-- Users (Administrators) table
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Students table
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no TEXT UNIQUE NOT NULL COLLATE NOCASE,
    name TEXT NOT NULL,
    email TEXT,
    department TEXT NOT NULL,
    course TEXT NOT NULL,
    semester INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for student searches
CREATE INDEX IF NOT EXISTS idx_students_roll ON students(roll_no);
CREATE INDEX IF NOT EXISTS idx_students_name ON students(name);
CREATE INDEX IF NOT EXISTS idx_students_dept ON students(department, course, semester);

-- Examinations table
CREATE TABLE IF NOT EXISTS examinations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exam_name TEXT NOT NULL,
    exam_code TEXT UNIQUE NOT NULL COLLATE NOCASE,
    subject TEXT NOT NULL,
    department TEXT NOT NULL,
    exam_date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    session TEXT NOT NULL DEFAULT 'Morning',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_exams_date ON examinations(exam_date);
CREATE INDEX IF NOT EXISTS idx_exams_code ON examinations(exam_code);

-- Rooms table
CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_name TEXT NOT NULL,
    room_number TEXT UNIQUE NOT NULL COLLATE NOCASE,
    building TEXT NOT NULL,
    floor INTEGER NOT NULL DEFAULT 1,
    capacity INTEGER NOT NULL CHECK (capacity > 0),
    rows_count INTEGER NOT NULL DEFAULT 5 CHECK (rows_count > 0),
    cols_count INTEGER NOT NULL DEFAULT 6 CHECK (cols_count > 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_rooms_number ON rooms(room_number);

-- Exam Registrations table (maps students enrolled in an examination)
CREATE TABLE IF NOT EXISTS exam_registrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exam_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES examinations(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    UNIQUE (exam_id, student_id)
);

CREATE INDEX IF NOT EXISTS idx_reg_exam ON exam_registrations(exam_id);
CREATE INDEX IF NOT EXISTS idx_reg_student ON exam_registrations(student_id);

-- Seat Allocations table
CREATE TABLE IF NOT EXISTS allocations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exam_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    room_id INTEGER NOT NULL,
    seat_number INTEGER NOT NULL,
    seat_label TEXT NOT NULL,
    allocated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES examinations(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE RESTRICT,
    UNIQUE (exam_id, student_id),
    UNIQUE (exam_id, room_id, seat_number)
);

CREATE INDEX IF NOT EXISTS idx_alloc_exam ON allocations(exam_id);
CREATE INDEX IF NOT EXISTS idx_alloc_room ON allocations(room_id);
CREATE INDEX IF NOT EXISTS idx_alloc_student ON allocations(student_id);

-- Allocation Runs Log (tracks allocation activity for dashboard)
CREATE TABLE IF NOT EXISTS allocation_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exam_id INTEGER NOT NULL,
    total_registered INTEGER NOT NULL,
    total_allocated INTEGER NOT NULL,
    total_unallocated INTEGER NOT NULL,
    rooms_used TEXT NOT NULL,
    run_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES examinations(id) ON DELETE CASCADE
);

-- System Settings
CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

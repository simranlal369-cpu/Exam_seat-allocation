import functools
import hmac
import secrets
from flask import session, redirect, url_for, request, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

def generate_csrf_token():
    """Generate or retrieve a CSRF token for the current session."""
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    return session['csrf_token']

def verify_csrf_token(token):
    """Validate submitted CSRF token using constant-time comparison."""
    session_token = session.get('csrf_token')
    if not session_token or not token:
        return False
    return hmac.compare_digest(session_token, token)

def login_required(view):
    """Decorator to require login for protected routes."""
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if session.get('user_id') is None:
            flash('Please log in with administrator credentials to access this page.', 'warning')
            return redirect(url_for('login', next=request.path))
        return view(**kwargs)
    return wrapped_view

def hash_password(password):
    """Hash password securely using Werkzeug default PBKDF2/scrypt."""
    return generate_password_hash(password)

def verify_password(stored_hash, password):
    """Verify password against stored hash."""
    return check_password_hash(stored_hash, password)

import sqlite3

class AllocationError(Exception):
    """Custom exception for allocation logic errors."""
    pass

class AllocationConflictError(AllocationError):
    """Exception raised when an allocation already exists and overwrite is not confirmed."""
    pass

def get_exam_allocation_preview(db, exam_id, room_ids):
    """
    Returns registered student count, total capacity for selected rooms,
    and checks if existing allocations are present.
    """
    # Registered student count
    cur = db.cursor()
    cur.execute("""
        SELECT COUNT(*) AS count
        FROM exam_registrations
        WHERE exam_id = ?
    """, (exam_id,))
    reg_row = cur.fetchone()
    registered_count = reg_row['count'] if reg_row else 0

    # Selected rooms details and total capacity
    selected_rooms = []
    total_capacity = 0
    if room_ids:
        placeholders = ','.join('?' for _ in room_ids)
        cur.execute(f"""
            SELECT id, room_name, room_number, building, floor, capacity, rows_count, cols_count
            FROM rooms
            WHERE id IN ({placeholders})
            ORDER BY room_number ASC
        """, room_ids)
        selected_rooms = [dict(r) for r in cur.fetchall()]
        total_capacity = sum(r['capacity'] for r in selected_rooms)

    # Existing allocation count
    cur.execute("SELECT COUNT(*) AS count FROM allocations WHERE exam_id = ?", (exam_id,))
    existing_row = cur.fetchone()
    existing_count = existing_row['count'] if existing_row else 0

    return {
        'registered_count': registered_count,
        'selected_rooms': selected_rooms,
        'total_capacity': total_capacity,
        'capacity_difference': total_capacity - registered_count,
        'has_existing_allocation': existing_count > 0,
        'existing_allocation_count': existing_count
    }

def execute_allocation(db, exam_id, room_ids, allow_overwrite=False):
    """
    Executes seat allocation for an exam across selected rooms:
    - Sorts registered students by roll_no ASC.
    - Allocates seats sequentially across rooms.
    - Uses seat label format: {room_number}-{seat_number:02d}.
    - Handles capacity shortfall clearly.
    - Enforces transactional integrity and prevents duplicate assignments.
    """
    if not room_ids:
        raise AllocationError("Please select at least one examination room for seat allocation.")

    cur = db.cursor()

    # Verify examination exists
    cur.execute("SELECT id, exam_name, exam_code FROM examinations WHERE id = ?", (exam_id,))
    exam = cur.fetchone()
    if not exam:
        raise AllocationError("Examination not found.")

    # Check for existing allocations
    cur.execute("SELECT COUNT(*) AS count FROM allocations WHERE exam_id = ?", (exam_id,))
    existing_count = cur.fetchone()['count']
    if existing_count > 0 and not allow_overwrite:
        raise AllocationConflictError(
            f"Active allocation with {existing_count} seat(s) already exists for this examination. "
            "Please confirm regeneration to replace it."
        )

    # Fetch registered students in sorted roll_no order
    cur.execute("""
        SELECT s.id, s.roll_no, s.name, s.department, s.course, s.semester
        FROM students s
        JOIN exam_registrations er ON s.id = er.student_id
        WHERE er.exam_id = ?
        ORDER BY s.roll_no ASC
    """, (exam_id,))
    registered_students = [dict(s) for s in cur.fetchall()]

    if not registered_students:
        raise AllocationError(
            "No students are currently registered for this examination. "
            "Please register students before allocating seats."
        )

    # Fetch selected rooms
    placeholders = ','.join('?' for _ in room_ids)
    cur.execute(f"""
        SELECT id, room_name, room_number, building, floor, capacity, rows_count, cols_count
        FROM rooms
        WHERE id IN ({placeholders})
        ORDER BY room_number ASC
    """, room_ids)
    rooms = [dict(r) for r in cur.fetchall()]

    if not rooms:
        raise AllocationError("Selected rooms could not be found.")

    total_capacity = sum(r['capacity'] for r in rooms)

    # Perform atomic allocation
    try:
        # Clear existing allocations for this exam if overwrite allowed
        if existing_count > 0 and allow_overwrite:
            cur.execute("DELETE FROM allocations WHERE exam_id = ?", (exam_id,))

        allocated_records = []
        rooms_summary = []
        student_idx = 0
        total_students = len(registered_students)

        for room in rooms:
            room_allocated_count = 0
            cap = room['capacity']
            for seat_num in range(1, cap + 1):
                if student_idx < total_students:
                    st = registered_students[student_idx]
                    # Unique seat label: e.g. A-101-01
                    clean_room_num = room['room_number'].replace(" ", "")
                    seat_label = f"{clean_room_num}-{seat_num:02d}"

                    cur.execute("""
                        INSERT INTO allocations (exam_id, student_id, room_id, seat_number, seat_label)
                        VALUES (?, ?, ?, ?, ?)
                    """, (exam_id, st['id'], room['id'], seat_num, seat_label))

                    allocated_records.append({
                        'student_id': st['id'],
                        'roll_no': st['roll_no'],
                        'name': st['name'],
                        'department': st['department'],
                        'room_id': room['id'],
                        'room_number': room['room_number'],
                        'room_name': room['room_name'],
                        'seat_number': seat_num,
                        'seat_label': seat_label
                    })

                    student_idx += 1
                    room_allocated_count += 1
                else:
                    break

            rooms_summary.append({
                'room_id': room['id'],
                'room_name': room['room_name'],
                'room_number': room['room_number'],
                'capacity': room['capacity'],
                'allocated_count': room_allocated_count,
                'vacant_count': room['capacity'] - room_allocated_count
            })

            if student_idx >= total_students:
                break

        # Check if any unallocated students remain
        unallocated_students = []
        if student_idx < total_students:
            unallocated_students = registered_students[student_idx:]

        # Log allocation run in allocation_runs table
        rooms_used_str = ", ".join([r['room_number'] for r in rooms_summary if r['allocated_count'] > 0])
        cur.execute("""
            INSERT INTO allocation_runs (exam_id, total_registered, total_allocated, total_unallocated, rooms_used)
            VALUES (?, ?, ?, ?, ?)
        """, (exam_id, total_students, len(allocated_records), len(unallocated_students), rooms_used_str))

        db.commit()

        return {
            'success': True,
            'exam_name': exam['exam_name'],
            'exam_code': exam['exam_code'],
            'total_registered': total_students,
            'total_capacity': total_capacity,
            'total_allocated': len(allocated_records),
            'total_unallocated': len(unallocated_students),
            'rooms_summary': rooms_summary,
            'unallocated_students': unallocated_students,
            'allocated_records': allocated_records
        }

    except Exception as e:
        db.rollback()
        raise AllocationError(f"Database error during seat allocation: {str(e)}")

def get_seating_matrix(db, exam_id, room_id):
    """
    Builds a structured 2D grid matrix of the room layout with
    occupied and vacant desk representations.
    """
    cur = db.cursor()

    # Room details
    cur.execute("""
        SELECT id, room_name, room_number, building, floor, capacity, rows_count, cols_count
        FROM rooms
        WHERE id = ?
    """, (room_id,))
    room = cur.fetchone()
    if not room:
        return None

    # Allocations for this room and exam
    cur.execute("""
        SELECT a.seat_number, a.seat_label, s.roll_no, s.name, s.department, s.course, s.semester
        FROM allocations a
        JOIN students s ON a.student_id = s.id
        WHERE a.exam_id = ? AND a.room_id = ?
        ORDER BY a.seat_number ASC
    """, (exam_id, room_id))
    alloc_map = {row['seat_number']: dict(row) for row in cur.fetchall()}

    rows = room['rows_count']
    cols = room['cols_count']
    capacity = room['capacity']

    # Generate grid
    grid = []
    seat_counter = 1
    occupied_count = 0

    for r in range(1, rows + 1):
        row_cells = []
        for c in range(1, cols + 1):
            if seat_counter <= capacity:
                clean_num = room['room_number'].replace(" ", "")
                default_label = f"{clean_num}-{seat_counter:02d}"
                if seat_counter in alloc_map:
                    alloc = alloc_map[seat_counter]
                    row_cells.append({
                        'seat_number': seat_counter,
                        'seat_label': alloc['seat_label'],
                        'is_seat': True,
                        'is_occupied': True,
                        'student_name': alloc['name'],
                        'roll_no': alloc['roll_no'],
                        'department': alloc['department'],
                        'course': alloc['course'],
                        'semester': alloc['semester'],
                        'row_idx': r,
                        'col_idx': c
                    })
                    occupied_count += 1
                else:
                    row_cells.append({
                        'seat_number': seat_counter,
                        'seat_label': default_label,
                        'is_seat': True,
                        'is_occupied': False,
                        'student_name': None,
                        'roll_no': None,
                        'department': None,
                        'course': None,
                        'semester': None,
                        'row_idx': r,
                        'col_idx': c
                    })
                seat_counter += 1
            else:
                # Extra slot beyond capacity (e.g. aisle or empty desk position)
                row_cells.append({
                    'seat_number': None,
                    'seat_label': '',
                    'is_seat': False,
                    'is_occupied': False,
                    'row_idx': r,
                    'col_idx': c
                })
        grid.append(row_cells)

    vacant_count = capacity - occupied_count
    occupancy_pct = round((occupied_count / capacity * 100), 1) if capacity > 0 else 0

    return {
        'room': dict(room),
        'grid': grid,
        'capacity': capacity,
        'occupied_count': occupied_count,
        'vacant_count': vacant_count,
        'occupancy_pct': occupancy_pct
    }
